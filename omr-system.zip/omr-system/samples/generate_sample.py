"""
Generate a synthetic filled OMR sheet (PNG) matching the default template
in omr-engine/omr_processor.py. Useful for testing the end-to-end pipeline.

Usage:
  python generate_sample.py [num_filled=100] [output.png]
"""
import sys
import os
import random
import numpy as np
import cv2

W, H = 800, 1100  # warped size used by the engine

# Layout constants (must match DEFAULT_TEMPLATE)
GRID_TOP_F = 0.30
GRID_BOTTOM_F = 0.95
GRID_LEFT_F = 0.05
GRID_RIGHT_F = 0.95
COLS = 4
ROWS = 25
OPTS = 4
BUBBLE_AREA_LEFT_F = 0.30
BUBBLE_AREA_RIGHT_F = 0.95


def render(answer_key=None, fill_prob=1.0, output="sample_sheet.png", seed=42):
    rng = random.Random(seed)
    img = np.full((H, W, 3), 255, dtype=np.uint8)

    # Black border (helps the engine's sheet-contour finder)
    cv2.rectangle(img, (8, 8), (W - 9, H - 9), (0, 0, 0), 4)

    # Header
    cv2.rectangle(img, (40, 40), (W - 40, 250), (240, 240, 240), -1)
    cv2.rectangle(img, (40, 40), (W - 40, 250), (0, 0, 0), 1)
    cv2.putText(img, "OMR Answer Sheet (SAMPLE)", (60, 90),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 0), 2)
    cv2.putText(img, "Roll No: 123456", (60, 140),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1)
    cv2.putText(img, "Exam: DEMO100", (60, 170),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 1)

    # Compute grid pixel positions
    g_top = int(GRID_TOP_F * H)
    g_bot = int(GRID_BOTTOM_F * H)
    g_left = int(GRID_LEFT_F * W)
    g_right = int(GRID_RIGHT_F * W)
    col_w = (g_right - g_left) / COLS
    row_h = (g_bot - g_top) / ROWS

    answers = {}
    qnum = 0
    for col in range(COLS):
        for row in range(ROWS):
            qnum += 1
            cell_x0 = g_left + col * col_w
            cell_y0 = g_top + row * row_h
            cell_x1 = cell_x0 + col_w
            cell_y1 = cell_y0 + row_h

            # Q number label
            cv2.putText(img, f"{qnum}.",
                        (int(cell_x0 + 4), int(cell_y0 + row_h / 2 + 5)),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 0, 0), 1)

            bub_x0 = cell_x0 + col_w * BUBBLE_AREA_LEFT_F
            bub_x1 = cell_x0 + col_w * BUBBLE_AREA_RIGHT_F
            bub_w = (bub_x1 - bub_x0) / OPTS

            # Decide which option to fill (or skip)
            if answer_key and str(qnum) in answer_key:
                fill_idx = ["A", "B", "C", "D"].index(answer_key[str(qnum)][0])
            else:
                fill_idx = rng.randint(0, 3)
            do_fill = rng.random() < fill_prob

            for o in range(OPTS):
                cx = int(bub_x0 + (o + 0.5) * bub_w)
                cy = int(cell_y0 + row_h / 2)
                radius = max(6, int(min(row_h, bub_w) / 3))
                cv2.circle(img, (cx, cy), radius, (0, 0, 0), 1)
                if o == fill_idx and do_fill:
                    cv2.circle(img, (cx, cy), radius - 1, (0, 0, 0), -1)
                else:
                    # faint option label
                    cv2.putText(img, "ABCD"[o], (cx - 4, cy + 4),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.35, (180, 180, 180), 1)
            if do_fill:
                answers[qnum] = "ABCD"[fill_idx]

    cv2.imwrite(output, img)
    print(f"✓ Saved {output} ({W}x{H})")
    return answers


if __name__ == "__main__":
    out = sys.argv[2] if len(sys.argv) > 2 else "sample_sheet.png"
    # Build an answer key cycling A,B,C,D
    key = {str(i): ["ABCD"[i % 4]] for i in range(1, 101)}
    answers = render(answer_key=key, output=out)
    # Write key as JSON for reference
    import json
    with open(os.path.splitext(out)[0] + "_key.json", "w") as f:
        json.dump(key, f)
    print(f"✓ Wrote answer key: {os.path.splitext(out)[0]}_key.json")
