# 📡 API Documentation

Base URL: `http://localhost:5000/api`

All non-auth endpoints require header: `Authorization: Bearer <JWT>`

---

## 🔐 Authentication

### `POST /auth/register`
**Body:** `{ name, email, password, role?, rollNumber?, phone?, institution? }`
**Returns:** `{ token, user }`

### `POST /auth/login`
**Body:** `{ email, password }`
**Returns:** `{ token, user }`

### `GET /auth/me`
Returns the current authenticated user.

---

## 👥 Users (admin)

| Method | Path | Description |
|--------|------|-------------|
| GET    | `/users?q=&role=` | List/search users |
| PATCH  | `/users/:id` | Update role/active/profile |
| DELETE | `/users/:id` | Delete user |

---

## 📚 Exams

| Method | Path | Roles | Description |
|--------|------|-------|-------------|
| POST   | `/exams` | admin, evaluator | Create exam |
| GET    | `/exams?status=` | all | List exams (students see active/completed only) |
| GET    | `/exams/:id` | all | Get single exam |
| PATCH  | `/exams/:id` | admin, evaluator | Update exam |
| DELETE | `/exams/:id` | admin | Delete exam |
| POST   | `/exams/:id/answer-key` | admin, evaluator | Upload answer key `{ answerKey: { "1": ["A"], ... } }` |
| GET    | `/exams/:id/qrcode` | all | Generate QR code for the exam |

**Exam payload example:**
```json
{
  "title": "Physics Mid-term",
  "subject": "Physics",
  "totalQuestions": 100,
  "marksPerQuestion": 1,
  "negativeMarking": 0.25,
  "allowMultipleAnswers": false,
  "durationMinutes": 90,
  "passPercentage": 33,
  "status": "active"
}
```

---

## 🖨️ Scanning

### `POST /scan/upload`  (multipart/form-data)
**Fields:**
- `file` — JPG/PNG/BMP/PDF (max 20 MB)
- `examId` — exam to evaluate against
- `studentId` *(optional)* — link submission to a specific student

**Returns:** Full `submission` object with `score`, `percentage`, per-question `answers`, etc.

### `POST /scan/bulk`  (multipart/form-data, admin/evaluator)
- `files[]` — up to 50 files
- `examId`

Returns array of per-file results.

---

## 🏆 Results

| Method | Path | Description |
|--------|------|-------------|
| GET | `/results/exam/:examId` | All submissions for an exam (ranked) |
| GET | `/results/:submissionId` | Single submission detail |
| GET | `/results/student/me` | Current student's own results |
| PATCH | `/results/:id/review` | Manual override (admin/evaluator) |
| GET | `/results/:id/scorecard.pdf` | Download PDF scorecard |
| GET | `/results/exam/:examId/export.xlsx` | Export Excel |
| GET | `/results/exam/:examId/export.csv` | Export CSV |

---

## 📊 Analytics

### `GET /analytics/exam/:examId`
Returns:
```json
{
  "totalSubmissions": 45,
  "avgScore": 64.3,
  "avgPercentage": 64.3,
  "passPercent": 71.1,
  "highestScore": 95,
  "toppers": [...],
  "questionAccuracy": [{ "question": 1, "accuracy": 82.2, "difficulty": "Easy" }, ...],
  "difficulty": { "easy": 40, "medium": 35, "hard": 25 },
  "distribution": [...]
}
```

### `GET /analytics/overview`
Admin dashboard stats.

---

## 🛡️ Audit (admin)

### `GET /audit?action=&resource=&limit=`
Returns recent audit log entries.

---

## 🧠 OMR Engine (direct, internal)

These are the underlying Python microservice endpoints — usually called by the Node backend, but exposed for testing:

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check |
| POST | `/scan` | multipart `file` → detected answers |
| POST | `/evaluate` | JSON `{ answers, answer_key, ... }` → score |
| POST | `/scan-and-eval` | combined scan + evaluate |
| GET | `/template` | Get the default OMR template config |
