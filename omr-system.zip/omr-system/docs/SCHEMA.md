# 🗄️ Database Schema (MongoDB)

## `users`
| Field | Type | Notes |
|-------|------|-------|
| `_id` | ObjectId | PK |
| `name` | String | required |
| `email` | String | unique, lowercase, indexed |
| `password` | String | bcrypt hash, `select: false` |
| `role` | enum | `admin` / `evaluator` / `student` |
| `rollNumber` | String | indexed (sparse) |
| `phone` | String | optional |
| `institution` | String | optional |
| `isActive` | Boolean | default `true` |
| `createdAt`, `updatedAt` | Date | auto |

## `exams`
| Field | Type | Notes |
|-------|------|-------|
| `_id` | ObjectId | |
| `title` | String | required |
| `description` | String | |
| `subject` | String | |
| `totalQuestions` | Number | default 100 |
| `marksPerQuestion` | Number | default 1 |
| `negativeMarking` | Number | e.g. 0.25 |
| `allowMultipleAnswers` | Boolean | default false |
| `durationMinutes` | Number | |
| `passPercentage` | Number | default 33 |
| `answerKey` | Map<String, [String]> | `{ "1": ["A"], "2": ["B","C"] }` |
| `subjectMap` | Map<String, String> | `{ "1": "Math" }` (optional) |
| `examCode` | String | unique, used in QR validation |
| `status` | enum | draft/active/completed/archived |
| `createdBy` | ObjectId → users | |
| `scheduledAt` | Date | |

## `submissions`
| Field | Type | Notes |
|-------|------|-------|
| `exam` | ObjectId → exams | indexed |
| `student` | ObjectId → users | optional, indexed |
| `rollNumber` | String | from OCR or matched user |
| `qrData` | String | decoded QR/barcode payload |
| `scanImageUrl` | String | original upload path |
| `previewImageB64` | String | small warped JPEG (data URL) |
| `answers` | [AnswerDetail] | per-question evaluation |
| `score`, `maxScore`, `percentage` | Number | |
| `correctCount`, `wrongCount`, `skippedCount` | Number | |
| `subjectBreakdown` | Map<String, Object> | per-subject stats |
| `rank` | Number | computed |
| `isPassed` | Boolean | |
| `needsManualReview` | Boolean | low confidence flag |
| `reviewedBy` | ObjectId → users | |
| `reviewedAt` | Date | |
| `scanFingerprint` | String | sha256 of `examId+qr/roll/filename`, unique per exam |
| `submittedBy` | ObjectId → users | uploader |

### Embedded `AnswerDetail`
```js
{
  question: Number,
  selected: [String],         // ["A"]
  correctAnswer: [String],    // ["B"]
  verdict: "correct"|"wrong"|"skipped"|"partial"|"invalid_multi",
  marks: Number,
  confidence: Number,         // 0..1
  needsReview: Boolean
}
```

## `auditlogs`
| Field | Type | Notes |
|-------|------|-------|
| `user` | ObjectId → users | |
| `userEmail` | String | denormalized for queries |
| `action` | String | e.g. `scan.submit`, `user.login` |
| `resource` | String | e.g. `Exam`, `Submission` |
| `resourceId` | String | |
| `details` | Object | freeform |
| `ip`, `userAgent` | String | |
| `createdAt` | Date | indexed |

---

## 🔧 Indexes
- `users.email` (unique)
- `users.rollNumber` (sparse)
- `users.role`
- `exams.examCode` (unique sparse)
- `submissions.{exam, rollNumber}`
- `submissions.{exam, scanFingerprint}` (unique sparse) — **duplicate scan prevention**
- `auditlogs.action`
