# 🚀 Production Deployment Guide

## Option 1 — Docker Compose (Single Server)

**Requirements:** Linux VPS, 2 vCPU / 4 GB RAM, Docker & Docker Compose installed.

```bash
git clone <your-repo>
cd omr-system
# Edit secrets
nano docker-compose.yml   # set JWT_SECRET to a long random string
docker-compose up -d --build
docker-compose exec backend npm run seed   # create default users
```

Access:
- Frontend: `http://<server-ip>:5173`
- API: `http://<server-ip>:5000`

### Add HTTPS via Caddy (recommended)

`Caddyfile`:
```
omr.yourdomain.com {
  reverse_proxy localhost:5173
}
api.omr.yourdomain.com {
  reverse_proxy localhost:5000
}
```

```bash
sudo apt install caddy
sudo systemctl restart caddy
```

Update `frontend/nginx.conf` `proxy_pass` to `https://api.omr.yourdomain.com` if frontend & API are on separate domains.

---

## Option 2 — AWS

| Component | AWS Service |
|-----------|-------------|
| Frontend | S3 + CloudFront |
| Backend | ECS Fargate or EC2 (t3.small+) |
| OMR Engine | ECS Fargate (1 vCPU, 2 GB RAM, ARM-compatible) |
| Database | MongoDB Atlas (free tier ok for dev) |
| File storage | S3 (replace local `/uploads`) |
| Auth | JWT (built-in) — or Cognito as upgrade |

**Steps:**
1. Build Docker images & push to ECR.
2. Create ECS cluster with two services: `backend`, `omr-engine` (private VPC, ALB in front).
3. Frontend: `npm run build` → upload `dist/` to S3 → CloudFront in front.
4. MongoDB: create cluster on Atlas → put SRV URI into ECS task env (`MONGO_URI`).
5. Set `OMR_ENGINE_URL` env on backend service to `omr-engine` internal DNS.
6. (Optional) Add S3 bucket for uploads — see `backend/src/utils/storage.js` (extension point).

---

## Option 3 — Render / Railway / Fly.io

Each service has its own folder; each can be deployed as a separate web service:
- `omr-system/omr-engine` (Dockerfile) → Render web service
- `omr-system/backend` (Dockerfile) → Render web service, env vars set in dashboard
- `omr-system/frontend` (Dockerfile or static build) → Render static site

Use Render's managed MongoDB or MongoDB Atlas.

---

## 🔒 Production Checklist

- [ ] Change `JWT_SECRET` to a 64+ char random string (`openssl rand -hex 64`)
- [ ] Use a managed MongoDB (Atlas / DocumentDB) with auth + TLS
- [ ] Configure HTTPS (Caddy/Nginx/CloudFront)
- [ ] Set `NODE_ENV=production` on backend
- [ ] Move `/uploads` to S3/Cloudinary for multi-instance scaling
- [ ] Restrict CORS to your frontend origin (currently `*` for dev)
- [ ] Enable MongoDB backups (Atlas → automatic; self-hosted → cron `mongodump`)
- [ ] Add log aggregation (e.g., CloudWatch, Datadog, Logtail)
- [ ] Configure rate limits more aggressively (`express-rate-limit`)
- [ ] Add monitoring (UptimeRobot for `/health`)

---

## 📈 Scaling

- **OMR Engine** is CPU-bound (OpenCV). Scale horizontally — run 2–4 replicas behind a load balancer for high throughput.
- **Backend** is I/O-bound — scale to 2–3 replicas; use sticky sessions only if needed.
- **MongoDB** — enable replica set; index `submissions.exam` & `submissions.scanFingerprint`.
- Use a Redis cache for analytics endpoints if you have > 10k submissions per exam.

---

## 🧪 Smoke Test in Production

```bash
curl https://api.omr.yourdomain.com/health
# {"status":"ok",...}

curl -X POST https://api.omr.yourdomain.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@omr.com","password":"admin123"}'
```
