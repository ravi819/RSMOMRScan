module.exports = function errorHandler(err, req, res, next) {
  console.error("[ERROR]", err);
  const status = err.statusCode || 500;
  res.status(status).json({
    error: err.message || "Internal server error",
    ...(process.env.NODE_ENV !== "production" && { stack: err.stack }),
  });
};
