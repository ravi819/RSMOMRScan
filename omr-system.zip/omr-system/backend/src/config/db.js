const mongoose = require("mongoose");

module.exports = async function connectDB() {
  const uri = process.env.MONGO_URI || "mongodb://localhost:27017/omr_system";
  await mongoose.connect(uri);
  console.log("✅ MongoDB connected:", uri);
};
