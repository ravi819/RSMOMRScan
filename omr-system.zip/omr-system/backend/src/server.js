require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
const path = require("path");

const connectDB = require("./config/db");
const errorHandler = require("./middleware/errorHandler");

const authRoutes = require("./routes/auth");
const userRoutes = require("./routes/users");
const examRoutes = require("./routes/exams");
const scanRoutes = require("./routes/scan");
const resultRoutes = require("./routes/results");
const analyticsRoutes = require("./routes/analytics");
const auditRoutes = require("./routes/audit");

const app = express();

// Security & parsers
app.use(helmet({ crossOriginResourcePolicy: false }));
app.use(cors());
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ extended: true, limit: "20mb" }));
app.use(morgan("dev"));

// Rate limit auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use("/api/auth", authLimiter);

// Static uploads
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

// Health
app.get("/health", (req, res) =>
  res.json({ status: "ok", service: "omr-backend", time: new Date().toISOString() })
);

// API routes
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/exams", examRoutes);
app.use("/api/scan", scanRoutes);
app.use("/api/results", resultRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/api/audit", auditRoutes);

// 404
app.use((req, res) => res.status(404).json({ error: "Not found" }));

// Error handler
app.use(errorHandler);

// Startup
const PORT = process.env.PORT || 5000;
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 OMR Backend listening on http://localhost:${PORT}`);
    console.log(`   OMR Engine: ${process.env.OMR_ENGINE_URL || "http://localhost:8000"}`);
  });
}).catch((err) => {
  console.error("DB connection failed:", err.message);
  process.exit(1);
});
