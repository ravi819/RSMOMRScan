const express = require("express");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const User = require("../models/User");
const { authenticate } = require("../middleware/auth");
const { logAudit } = require("../utils/audit");

const router = express.Router();

function signToken(user) {
  return jwt.sign(
    { id: user._id, role: user.role, email: user.email },
    process.env.JWT_SECRET || "dev_secret",
    { expiresIn: process.env.JWT_EXPIRES_IN || "24h" }
  );
}

// POST /api/auth/register
router.post(
  "/register",
  [
    body("email").isEmail(),
    body("password").isLength({ min: 6 }),
    body("name").notEmpty(),
  ],
  async (req, res, next) => {
    try {
      const errs = validationResult(req);
      if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });

      const { name, email, password, role, rollNumber, phone, institution } = req.body;
      const existing = await User.findOne({ email: email.toLowerCase() });
      if (existing) return res.status(409).json({ error: "Email already registered" });

      // Only admins can create non-student accounts via API in production.
      // For MVP / first-bootstrap we allow any role from /register.
      const user = await User.create({
        name,
        email: email.toLowerCase(),
        password,
        role: role || "student",
        rollNumber,
        phone,
        institution,
      });

      const token = signToken(user);
      await logAudit(req, "user.register", "User", user._id, { email });
      res.status(201).json({ token, user: user.toSafeJSON() });
    } catch (err) { next(err); }
  }
);

// POST /api/auth/login
router.post(
  "/login",
  [body("email").isEmail(), body("password").notEmpty()],
  async (req, res, next) => {
    try {
      const { email, password } = req.body;
      const user = await User.findOne({ email: email.toLowerCase() }).select("+password");
      if (!user || !user.isActive) return res.status(401).json({ error: "Invalid credentials" });
      const ok = await user.comparePassword(password);
      if (!ok) return res.status(401).json({ error: "Invalid credentials" });

      const token = signToken(user);
      req.user = user;
      await logAudit(req, "user.login", "User", user._id, { email });
      res.json({ token, user: user.toSafeJSON() });
    } catch (err) { next(err); }
  }
);

// GET /api/auth/me
router.get("/me", authenticate, async (req, res) => {
  res.json({ user: req.user.toSafeJSON() });
});

module.exports = router;
