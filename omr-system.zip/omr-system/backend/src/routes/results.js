const express = require("express");
const PDFDocument = require("pdfkit");
const XLSX = require("xlsx");
const Submission = require("../models/Submission");
const Exam = require("../models/Exam");
const { authenticate, requireRole } = require("../middleware/auth");

const router = express.Router();

// GET /api/results/exam/:examId — list all submissions for an exam (ranked)
router.get("/exam/:examId", authenticate, requireRole("admin", "evaluator"),
  async (req, res, next) => {
    try {
      const subs = await Submission.find({ exam: req.params.examId })
        .populate("student", "name email rollNumber")
        .sort({ score: -1 });

      // assign rank
      const ranked = subs.map((s, i) => ({ ...s.toObject(), rank: i + 1 }));
      // persist rank
      await Promise.all(ranked.map(r =>
        Submission.findByIdAndUpdate(r._id, { rank: r.rank })
      ));
      res.json({ submissions: ranked });
    } catch (err) { next(err); }
  }
);

// GET /api/results/:submissionId — single result detail
router.get("/:submissionId", authenticate, async (req, res, next) => {
  try {
    const sub = await Submission.findById(req.params.submissionId)
      .populate("student", "name email rollNumber")
      .populate("exam");
    if (!sub) return res.status(404).json({ error: "Not found" });
    // Students can only see their own
    if (req.user.role === "student" &&
        sub.student?._id?.toString() !== req.user._id.toString() &&
        sub.rollNumber !== req.user.rollNumber) {
      return res.status(403).json({ error: "Forbidden" });
    }
    res.json({ submission: sub });
  } catch (err) { next(err); }
});

// GET /api/results/student/me — student's own results
router.get("/student/me", authenticate, async (req, res, next) => {
  try {
    const filter = req.user.rollNumber
      ? { $or: [{ student: req.user._id }, { rollNumber: req.user.rollNumber }] }
      : { student: req.user._id };
    const subs = await Submission.find(filter).populate("exam", "title subject totalQuestions");
    res.json({ submissions: subs });
  } catch (err) { next(err); }
});

// PATCH /api/results/:id/review — manual override
router.patch("/:id/review", authenticate, requireRole("admin", "evaluator"),
  async (req, res, next) => {
    try {
      const { answers, score, percentage } = req.body;
      const update = { reviewedBy: req.user._id, reviewedAt: new Date(), needsManualReview: false };
      if (answers) update.answers = answers;
      if (score !== undefined) update.score = score;
      if (percentage !== undefined) update.percentage = percentage;
      const sub = await Submission.findByIdAndUpdate(req.params.id, update, { new: true });
      res.json({ submission: sub });
    } catch (err) { next(err); }
  }
);

// GET /api/results/:id/scorecard.pdf — generate PDF scorecard
router.get("/:id/scorecard.pdf", authenticate, async (req, res, next) => {
  try {
    const sub = await Submission.findById(req.params.id)
      .populate("student", "name rollNumber email")
      .populate("exam");
    if (!sub) return res.status(404).json({ error: "Not found" });

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `inline; filename="scorecard_${sub._id}.pdf"`);

    const doc = new PDFDocument({ size: "A4", margin: 50 });
    doc.pipe(res);

    // Header
    doc.fontSize(22).fillColor("#1e40af").text("OFFICIAL SCORECARD", { align: "center" });
    doc.moveDown(0.3);
    doc.fontSize(12).fillColor("#64748b").text("AI OMR Evaluation System", { align: "center" });
    doc.moveDown(1);
    doc.strokeColor("#1e40af").lineWidth(2).moveTo(50, doc.y).lineTo(545, doc.y).stroke();
    doc.moveDown(0.8);

    // Student info
    doc.fontSize(13).fillColor("#0f172a");
    doc.text(`Student: ${sub.student?.name || "—"}`);
    doc.text(`Roll Number: ${sub.rollNumber || "—"}`);
    doc.text(`Exam: ${sub.exam?.title || "—"}`);
    doc.text(`Subject: ${sub.exam?.subject || "—"}`);
    doc.text(`Date: ${sub.createdAt.toLocaleString()}`);
    doc.moveDown(0.8);

    // Score box
    const boxY = doc.y;
    doc.rect(50, boxY, 495, 90).fillAndStroke("#dbeafe", "#1e40af");
    doc.fillColor("#1e3a8a").fontSize(11)
      .text("SCORE", 70, boxY + 12)
      .fontSize(28).text(`${sub.score} / ${sub.maxScore}`, 70, boxY + 28);
    doc.fontSize(11).text("PERCENTAGE", 250, boxY + 12)
      .fontSize(28).text(`${sub.percentage}%`, 250, boxY + 28);
    doc.fontSize(11).text("RANK", 430, boxY + 12)
      .fontSize(28).text(`#${sub.rank || "—"}`, 430, boxY + 28);
    doc.fillColor("#0f172a").moveDown(6);

    // Breakdown
    doc.fontSize(14).fillColor("#1e40af").text("Performance Summary");
    doc.moveDown(0.3);
    doc.fontSize(12).fillColor("#0f172a");
    doc.text(`✓  Correct:  ${sub.correctCount}`);
    doc.text(`✗  Wrong:    ${sub.wrongCount}`);
    doc.text(`○  Skipped:  ${sub.skippedCount}`);
    doc.text(`Result: ${sub.isPassed ? "PASSED ✓" : "NOT PASSED"}`);
    doc.moveDown(0.8);

    // Subject breakdown
    if (sub.subjectBreakdown && sub.subjectBreakdown.size > 0) {
      doc.fontSize(14).fillColor("#1e40af").text("Subject-wise Performance");
      doc.moveDown(0.3);
      doc.fontSize(11).fillColor("#0f172a");
      for (const [subj, stat] of sub.subjectBreakdown) {
        doc.text(`${subj}:  ${stat.correct}/${stat.total} correct, marks: ${stat.marks}`);
      }
      doc.moveDown(0.8);
    }

    // Footer
    doc.moveDown(2);
    doc.fontSize(9).fillColor("#94a3b8")
      .text(`Submission ID: ${sub._id}`, { align: "center" })
      .text("This is a system-generated scorecard.", { align: "center" });

    doc.end();
  } catch (err) { next(err); }
});

// GET /api/results/exam/:examId/export.xlsx
router.get("/exam/:examId/export.xlsx", authenticate, requireRole("admin", "evaluator"),
  async (req, res, next) => {
    try {
      const subs = await Submission.find({ exam: req.params.examId })
        .populate("student", "name email")
        .sort({ score: -1 });
      const rows = subs.map((s, i) => ({
        Rank: i + 1,
        RollNumber: s.rollNumber || "",
        Name: s.student?.name || "",
        Email: s.student?.email || "",
        Score: s.score,
        MaxScore: s.maxScore,
        Percentage: s.percentage,
        Correct: s.correctCount,
        Wrong: s.wrongCount,
        Skipped: s.skippedCount,
        Passed: s.isPassed ? "YES" : "NO",
        SubmittedAt: s.createdAt.toISOString(),
      }));
      const ws = XLSX.utils.json_to_sheet(rows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Results");
      const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
      res.setHeader("Content-Disposition", `attachment; filename="results_${req.params.examId}.xlsx"`);
      res.setHeader("Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
      res.send(buf);
    } catch (err) { next(err); }
  }
);

// GET /api/results/exam/:examId/export.csv
router.get("/exam/:examId/export.csv", authenticate, requireRole("admin", "evaluator"),
  async (req, res, next) => {
    try {
      const subs = await Submission.find({ exam: req.params.examId })
        .populate("student", "name email")
        .sort({ score: -1 });
      const header = "Rank,RollNumber,Name,Email,Score,MaxScore,Percentage,Correct,Wrong,Skipped,Passed";
      const lines = subs.map((s, i) => [
        i + 1, s.rollNumber || "", `"${s.student?.name || ""}"`, s.student?.email || "",
        s.score, s.maxScore, s.percentage, s.correctCount, s.wrongCount, s.skippedCount,
        s.isPassed ? "YES" : "NO",
      ].join(","));
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="results_${req.params.examId}.csv"`);
      res.send([header, ...lines].join("\n"));
    } catch (err) { next(err); }
  }
);

module.exports = router;
