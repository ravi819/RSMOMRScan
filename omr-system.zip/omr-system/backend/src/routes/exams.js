const express = require("express");
const crypto = require("crypto");
const QRCode = require("qrcode");
const Exam = require("../models/Exam");
const { authenticate, requireRole } = require("../middleware/auth");
const { logAudit } = require("../utils/audit");

const router = express.Router();

// POST /api/exams — create (admin/evaluator)
router.post("/", authenticate, requireRole("admin", "evaluator"), async (req, res, next) => {
  try {
    const data = req.body;
    data.createdBy = req.user._id;
    data.examCode = data.examCode || crypto.randomBytes(6).toString("hex").toUpperCase();
    const exam = await Exam.create(data);
    await logAudit(req, "exam.create", "Exam", exam._id, { title: exam.title });
    res.status(201).json({ exam });
  } catch (err) { next(err); }
});

// GET /api/exams — list (filtered by role)
router.get("/", authenticate, async (req, res, next) => {
  try {
    const filter = {};
    if (req.user.role === "student") filter.status = { $in: ["active", "completed"] };
    if (req.query.status) filter.status = req.query.status;
    const exams = await Exam.find(filter).sort({ createdAt: -1 }).limit(200);
    res.json({ exams });
  } catch (err) { next(err); }
});

// GET /api/exams/:id
router.get("/:id", authenticate, async (req, res, next) => {
  try {
    const exam = await Exam.findById(req.params.id);
    if (!exam) return res.status(404).json({ error: "Not found" });
    // Hide answer key from students unless exam is completed
    if (req.user.role === "student" && exam.status !== "completed") {
      const obj = exam.toObject();
      delete obj.answerKey;
      return res.json({ exam: obj });
    }
    res.json({ exam });
  } catch (err) { next(err); }
});

// PATCH /api/exams/:id
router.patch("/:id", authenticate, requireRole("admin", "evaluator"), async (req, res, next) => {
  try {
    const exam = await Exam.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!exam) return res.status(404).json({ error: "Not found" });
    await logAudit(req, "exam.update", "Exam", exam._id, Object.keys(req.body));
    res.json({ exam });
  } catch (err) { next(err); }
});

// DELETE /api/exams/:id
router.delete("/:id", authenticate, requireRole("admin"), async (req, res, next) => {
  try {
    await Exam.findByIdAndDelete(req.params.id);
    await logAudit(req, "exam.delete", "Exam", req.params.id);
    res.json({ ok: true });
  } catch (err) { next(err); }
});

// POST /api/exams/:id/answer-key — upload/replace answer key
router.post("/:id/answer-key", authenticate, requireRole("admin", "evaluator"),
  async (req, res, next) => {
    try {
      const { answerKey } = req.body; // { "1": ["A"], ... }
      if (!answerKey || typeof answerKey !== "object") {
        return res.status(400).json({ error: "answerKey object required" });
      }
      // Normalize string -> array
      const normalized = {};
      for (const [q, v] of Object.entries(answerKey)) {
        normalized[q] = Array.isArray(v) ? v : [v];
      }
      const exam = await Exam.findByIdAndUpdate(
        req.params.id,
        { answerKey: normalized },
        { new: true }
      );
      if (!exam) return res.status(404).json({ error: "Not found" });
      await logAudit(req, "exam.answerKey.update", "Exam", exam._id, {
        count: Object.keys(normalized).length,
      });
      res.json({ ok: true, exam });
    } catch (err) { next(err); }
  }
);

// GET /api/exams/:id/qrcode — generate QR for exam validation
router.get("/:id/qrcode", authenticate, async (req, res, next) => {
  try {
    const exam = await Exam.findById(req.params.id);
    if (!exam) return res.status(404).json({ error: "Not found" });
    const payload = JSON.stringify({ examCode: exam.examCode, examId: exam._id.toString() });
    const png = await QRCode.toDataURL(payload, { width: 300, margin: 1 });
    res.json({ qr: png, payload });
  } catch (err) { next(err); }
});

module.exports = router;
