const express = require("express");
const AuditLog = require("../models/AuditLog");
const { authenticate, requireRole } = require("../middleware/auth");

const router = express.Router();

// GET /api/audit?action=&resource=&limit=
router.get("/", authenticate, requireRole("admin"), async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.action) filter.action = req.query.action;
    if (req.query.resource) filter.resource = req.query.resource;
    if (req.query.user) filter.user = req.query.user;
    const limit = Math.min(parseInt(req.query.limit || "200", 10), 1000);
    const logs = await AuditLog.find(filter).sort({ createdAt: -1 }).limit(limit);
    res.json({ logs });
  } catch (err) { next(err); }
});

module.exports = router;
