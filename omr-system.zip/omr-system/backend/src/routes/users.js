const express = require("express");
const User = require("../models/User");
const { authenticate, requireRole } = require("../middleware/auth");
const { logAudit } = require("../utils/audit");

const router = express.Router();

// GET /api/users — admin only
router.get("/", authenticate, requireRole("admin"), async (req, res, next) => {
  try {
    const { role, q } = req.query;
    const filter = {};
    if (role) filter.role = role;
    if (q) filter.$or = [
      { name: new RegExp(q, "i") },
      { email: new RegExp(q, "i") },
      { rollNumber: new RegExp(q, "i") },
    ];
    const users = await User.find(filter).sort({ createdAt: -1 }).limit(500);
    res.json({ users });
  } catch (err) { next(err); }
});

// PATCH /api/users/:id — admin update role/active
router.patch("/:id", authenticate, requireRole("admin"), async (req, res, next) => {
  try {
    const { role, isActive, name, rollNumber, phone, institution } = req.body;
    const update = {};
    if (role) update.role = role;
    if (typeof isActive === "boolean") update.isActive = isActive;
    if (name) update.name = name;
    if (rollNumber !== undefined) update.rollNumber = rollNumber;
    if (phone !== undefined) update.phone = phone;
    if (institution !== undefined) update.institution = institution;

    const user = await User.findByIdAndUpdate(req.params.id, update, { new: true });
    if (!user) return res.status(404).json({ error: "User not found" });
    await logAudit(req, "user.update", "User", user._id, update);
    res.json({ user: user.toSafeJSON() });
  } catch (err) { next(err); }
});

// DELETE /api/users/:id
router.delete("/:id", authenticate, requireRole("admin"), async (req, res, next) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    await logAudit(req, "user.delete", "User", req.params.id);
    res.json({ ok: true });
  } catch (err) { next(err); }
});

module.exports = router;
