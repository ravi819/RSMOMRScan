const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const axios = require("axios");
const FormData = require("form-data");

const Exam = require("../models/Exam");
const Submission = require("../models/Submission");
const User = require("../models/User");
const { authenticate, requireRole } = require("../middleware/auth");
const { logAudit } = require("../utils/audit");

const router = express.Router();

// Multer storage
const uploadDir = path.join(__dirname, "..", "..", "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const unique = `${Date.now()}_${crypto.randomBytes(4).toString("hex")}${path.extname(file.originalname)}`;
    cb(null, unique);
  },
});
const MAX_MB = parseInt(process.env.MAX_UPLOAD_SIZE_MB || "20", 10);
const upload = multer({
  storage,
  limits: { fileSize: MAX_MB * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = /jpe?g|png|bmp|pdf/i.test(path.extname(file.originalname));
    cb(ok ? null : new Error("Only JPG/PNG/BMP/PDF allowed"), ok);
  },
});

const OMR_URL = process.env.OMR_ENGINE_URL || "http://localhost:8000";

/**
 * Helper: call OMR engine scan endpoint with a file path
 */
async function callOmrScan(filePath) {
  const form = new FormData();
  form.append("file", fs.createReadStream(filePath));
  const res = await axios.post(`${OMR_URL}/scan`, form, {
    headers: form.getHeaders(),
    maxBodyLength: 50 * 1024 * 1024,
    timeout: 120000,
  });
  return res.data;
}

/**
 * POST /api/scan/upload
 * Body (multipart): file, examId, [studentId]
 * Scans the sheet, evaluates against the exam's answer key, persists Submission.
 */
router.post(
  "/upload",
  authenticate,
  upload.single("file"),
  async (req, res, next) => {
    try {
      if (!req.file) return res.status(400).json({ error: "No file uploaded" });
      const { examId, studentId } = req.body;
      if (!examId) return res.status(400).json({ error: "examId required" });

      const exam = await Exam.findById(examId);
      if (!exam) return res.status(404).json({ error: "Exam not found" });

      // Call OMR engine
      const scan = await callOmrScan(req.file.path);
      if (!scan.success) {
        return res.status(422).json({ error: "OMR processing failed", details: scan });
      }

      // QR validation (if exam has QR enforcement & sheet had QR)
      if (scan.qr_data) {
        try {
          const parsed = JSON.parse(scan.qr_data);
          if (parsed.examCode && parsed.examCode !== exam.examCode) {
            return res.status(400).json({
              error: "QR mismatch — sheet belongs to a different exam",
              expected: exam.examCode, found: parsed.examCode,
            });
          }
        } catch { /* QR may not be JSON; ignore */ }
      }

      // Evaluate
      const answerKeyObj = {};
      for (const [k, v] of exam.answerKey) answerKeyObj[k] = v;

      const evalRes = await axios.post(`${OMR_URL}/evaluate`, {
        answers: scan.answers,
        answer_key: answerKeyObj,
        marks_per_q: exam.marksPerQuestion,
        negative_marking: exam.negativeMarking,
        allow_multiple: exam.allowMultipleAnswers,
      }, { timeout: 30000 });
      const ev = evalRes.data;

      // Subject breakdown
      const subjectBreakdown = {};
      if (exam.subjectMap && exam.subjectMap.size > 0) {
        for (const d of ev.details) {
          const subj = exam.subjectMap.get(String(d.question));
          if (!subj) continue;
          if (!subjectBreakdown[subj]) {
            subjectBreakdown[subj] = { correct: 0, wrong: 0, skipped: 0, marks: 0, total: 0 };
          }
          subjectBreakdown[subj].total++;
          subjectBreakdown[subj].marks += d.marks;
          if (d.verdict === "correct" || d.verdict === "partial") subjectBreakdown[subj].correct++;
          else if (d.verdict === "skipped") subjectBreakdown[subj].skipped++;
          else subjectBreakdown[subj].wrong++;
        }
      }

      // Duplicate prevention: fingerprint = sha256(examId + qr_data OR roll_number)
      const fingerprintSource = scan.qr_data || scan.roll_number || req.file.filename;
      const scanFingerprint = crypto
        .createHash("sha256")
        .update(`${examId}:${fingerprintSource}`)
        .digest("hex");

      // Resolve student
      let student = null;
      if (studentId) student = await User.findById(studentId);
      else if (scan.roll_number) {
        student = await User.findOne({ rollNumber: scan.roll_number, role: "student" });
      }

      // Check duplicate
      const dup = await Submission.findOne({ exam: examId, scanFingerprint });
      if (dup) {
        return res.status(409).json({
          error: "Duplicate scan detected — this sheet was already submitted",
          submissionId: dup._id,
        });
      }

      const needsManualReview = scan.answers.some(a => a.needs_review) ||
        scan.stats.avg_confidence < 0.4;

      const submission = await Submission.create({
        exam: examId,
        student: student?._id,
        rollNumber: scan.roll_number || student?.rollNumber,
        qrData: scan.qr_data,
        scanImageUrl: `/uploads/${req.file.filename}`,
        previewImageB64: scan.preview_image,
        answers: ev.details.map(d => ({
          question: d.question,
          selected: d.selected,
          correctAnswer: d.correct_answer,
          verdict: d.verdict,
          marks: d.marks,
          confidence: d.confidence,
          needsReview: d.needs_review,
        })),
        score: ev.score,
        maxScore: ev.max_score,
        percentage: ev.percentage,
        correctCount: ev.correct,
        wrongCount: ev.wrong,
        skippedCount: ev.skipped,
        subjectBreakdown,
        isPassed: ev.percentage >= exam.passPercentage,
        needsManualReview,
        scanFingerprint,
        submittedBy: req.user._id,
      });

      await logAudit(req, "scan.submit", "Submission", submission._id, {
        exam: exam.title, roll: submission.rollNumber, score: ev.score,
      });

      res.status(201).json({ submission });
    } catch (err) {
      console.error(err.response?.data || err.message);
      next(err);
    }
  }
);

/**
 * POST /api/scan/bulk — multiple files
 */
router.post(
  "/bulk",
  authenticate,
  requireRole("admin", "evaluator"),
  upload.array("files", 50),
  async (req, res, next) => {
    try {
      if (!req.files?.length) return res.status(400).json({ error: "No files" });
      const { examId } = req.body;
      if (!examId) return res.status(400).json({ error: "examId required" });
      const exam = await Exam.findById(examId);
      if (!exam) return res.status(404).json({ error: "Exam not found" });

      const answerKeyObj = {};
      for (const [k, v] of exam.answerKey) answerKeyObj[k] = v;

      const results = [];
      for (const file of req.files) {
        try {
          const scan = await callOmrScan(file.path);
          if (!scan.success) {
            results.push({ file: file.originalname, ok: false, error: "scan failed" });
            continue;
          }
          const evalRes = await axios.post(`${OMR_URL}/evaluate`, {
            answers: scan.answers,
            answer_key: answerKeyObj,
            marks_per_q: exam.marksPerQuestion,
            negative_marking: exam.negativeMarking,
            allow_multiple: exam.allowMultipleAnswers,
          });
          const ev = evalRes.data;

          const fp = crypto.createHash("sha256")
            .update(`${examId}:${scan.qr_data || scan.roll_number || file.filename}`)
            .digest("hex");

          if (await Submission.findOne({ exam: examId, scanFingerprint: fp })) {
            results.push({ file: file.originalname, ok: false, error: "duplicate" });
            continue;
          }

          const sub = await Submission.create({
            exam: examId,
            rollNumber: scan.roll_number,
            qrData: scan.qr_data,
            scanImageUrl: `/uploads/${file.filename}`,
            previewImageB64: scan.preview_image,
            answers: ev.details.map(d => ({
              question: d.question, selected: d.selected, correctAnswer: d.correct_answer,
              verdict: d.verdict, marks: d.marks, confidence: d.confidence,
              needsReview: d.needs_review,
            })),
            score: ev.score, maxScore: ev.max_score, percentage: ev.percentage,
            correctCount: ev.correct, wrongCount: ev.wrong, skippedCount: ev.skipped,
            isPassed: ev.percentage >= exam.passPercentage,
            needsManualReview: scan.stats.avg_confidence < 0.4,
            scanFingerprint: fp,
            submittedBy: req.user._id,
          });

          results.push({
            file: file.originalname, ok: true,
            submissionId: sub._id, roll: sub.rollNumber, score: sub.score,
          });
        } catch (e) {
          results.push({ file: file.originalname, ok: false, error: e.message });
        }
      }

      await logAudit(req, "scan.bulk", "Exam", examId, {
        total: req.files.length, ok: results.filter(r => r.ok).length,
      });
      res.json({ results });
    } catch (err) { next(err); }
  }
);

module.exports = router;
