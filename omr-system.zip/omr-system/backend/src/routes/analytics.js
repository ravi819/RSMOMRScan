const express = require("express");
const Submission = require("../models/Submission");
const Exam = require("../models/Exam");
const { authenticate, requireRole } = require("../middleware/auth");

const router = express.Router();

/**
 * GET /api/analytics/exam/:examId
 * Returns: topper list, pass %, average, question-wise accuracy, difficulty, distribution
 */
router.get("/exam/:examId", authenticate, requireRole("admin", "evaluator"),
  async (req, res, next) => {
    try {
      const examId = req.params.examId;
      const exam = await Exam.findById(examId);
      if (!exam) return res.status(404).json({ error: "Exam not found" });

      const subs = await Submission.find({ exam: examId })
        .populate("student", "name rollNumber")
        .sort({ score: -1 });

      const total = subs.length;
      if (total === 0) {
        return res.json({
          totalSubmissions: 0,
          message: "No submissions yet",
        });
      }

      const avgScore = subs.reduce((s, x) => s + x.score, 0) / total;
      const avgPercentage = subs.reduce((s, x) => s + x.percentage, 0) / total;
      const passed = subs.filter(s => s.isPassed).length;
      const passPercent = (passed / total) * 100;

      const toppers = subs.slice(0, 10).map((s, i) => ({
        rank: i + 1,
        name: s.student?.name || "—",
        rollNumber: s.rollNumber,
        score: s.score,
        percentage: s.percentage,
      }));

      // Question-wise accuracy
      const qStats = {};
      for (const sub of subs) {
        for (const a of sub.answers) {
          if (!qStats[a.question]) {
            qStats[a.question] = { correct: 0, wrong: 0, skipped: 0, total: 0 };
          }
          qStats[a.question].total++;
          if (a.verdict === "correct" || a.verdict === "partial") qStats[a.question].correct++;
          else if (a.verdict === "skipped") qStats[a.question].skipped++;
          else qStats[a.question].wrong++;
        }
      }
      const questionAccuracy = Object.entries(qStats).map(([q, st]) => ({
        question: parseInt(q, 10),
        accuracy: Math.round((st.correct / st.total) * 1000) / 10,
        attempted: st.total - st.skipped,
        skipped: st.skipped,
        difficulty:
          (st.correct / st.total) >= 0.75 ? "Easy" :
          (st.correct / st.total) >= 0.45 ? "Medium" : "Hard",
      })).sort((a, b) => a.question - b.question);

      // Score distribution (buckets of 10%)
      const distribution = Array.from({ length: 10 }, (_, i) => ({
        bucket: `${i * 10}-${i * 10 + 10}%`,
        count: 0,
      }));
      for (const s of subs) {
        const idx = Math.min(9, Math.floor(s.percentage / 10));
        distribution[idx].count++;
      }

      // Difficulty summary
      const difficulty = {
        easy: questionAccuracy.filter(q => q.difficulty === "Easy").length,
        medium: questionAccuracy.filter(q => q.difficulty === "Medium").length,
        hard: questionAccuracy.filter(q => q.difficulty === "Hard").length,
      };

      res.json({
        exam: { id: exam._id, title: exam.title, totalQuestions: exam.totalQuestions },
        totalSubmissions: total,
        avgScore: Math.round(avgScore * 100) / 100,
        avgPercentage: Math.round(avgPercentage * 100) / 100,
        passPercent: Math.round(passPercent * 100) / 100,
        passed,
        failed: total - passed,
        highestScore: subs[0]?.score || 0,
        lowestScore: subs[subs.length - 1]?.score || 0,
        toppers,
        questionAccuracy,
        difficulty,
        distribution,
      });
    } catch (err) { next(err); }
  }
);

// GET /api/analytics/overview — overall stats for admin home
router.get("/overview", authenticate, requireRole("admin", "evaluator"),
  async (req, res, next) => {
    try {
      const [totalExams, totalSubs, recentSubs] = await Promise.all([
        Exam.countDocuments(),
        Submission.countDocuments(),
        Submission.find().sort({ createdAt: -1 }).limit(10)
          .populate("exam", "title").populate("student", "name"),
      ]);
      const passed = await Submission.countDocuments({ isPassed: true });
      res.json({
        totalExams, totalSubmissions: totalSubs,
        passRate: totalSubs ? Math.round((passed / totalSubs) * 1000) / 10 : 0,
        recent: recentSubs,
      });
    } catch (err) { next(err); }
  }
);

module.exports = router;
