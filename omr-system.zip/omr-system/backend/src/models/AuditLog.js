const mongoose = require("mongoose");

const AuditLogSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    userEmail: String,
    action: { type: String, required: true, index: true },
    resource: String,
    resourceId: String,
    details: Object,
    ip: String,
    userAgent: String,
  },
  { timestamps: true }
);

module.exports = mongoose.model("AuditLog", AuditLogSchema);
