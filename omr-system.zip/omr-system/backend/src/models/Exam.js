const mongoose = require("mongoose");

const ExamSchema = new mongoose.Schema(
  {
    title: { type: String, required: true },
    description: String,
    subject: String,
    totalQuestions: { type: Number, required: true, default: 100 },
    marksPerQuestion: { type: Number, default: 1 },
    negativeMarking: { type: Number, default: 0 }, // e.g. 0.25
    allowMultipleAnswers: { type: Boolean, default: false },
    durationMinutes: { type: Number, default: 60 },
    passPercentage: { type: Number, default: 33 },
    // Answer key: { "1": ["A"], "2": ["B", "C"], ... }
    answerKey: {
      type: Map,
      of: [String],
      default: {},
    },
    // Optional per-subject mapping: { "1": "Math", "2": "Physics", ... }
    subjectMap: {
      type: Map,
      of: String,
      default: {},
    },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    status: {
      type: String,
      enum: ["draft", "active", "completed", "archived"],
      default: "draft",
    },
    examCode: { type: String, unique: true, sparse: true, index: true }, // for QR validation
    scheduledAt: Date,
  },
  { timestamps: true }
);

module.exports = mongoose.model("Exam", ExamSchema);
