const mongoose = require("mongoose");

const AnswerDetailSchema = new mongoose.Schema(
  {
    question: Number,
    selected: [String],
    correctAnswer: [String],
    verdict: {
      type: String,
      enum: ["correct", "wrong", "skipped", "partial", "invalid_multi"],
    },
    marks: Number,
    confidence: Number,
    needsReview: { type: Boolean, default: false },
  },
  { _id: false }
);

const SubmissionSchema = new mongoose.Schema(
  {
    exam: { type: mongoose.Schema.Types.ObjectId, ref: "Exam", required: true, index: true },
    student: { type: mongoose.Schema.Types.ObjectId, ref: "User", index: true },
    rollNumber: { type: String, index: true },
    qrData: String,
    scanImageUrl: String,        // path to original upload
    previewImageB64: String,     // small warped preview
    answers: [AnswerDetailSchema],
    score: { type: Number, default: 0 },
    maxScore: Number,
    percentage: Number,
    correctCount: Number,
    wrongCount: Number,
    skippedCount: Number,
    subjectBreakdown: { type: Map, of: Object, default: {} },
    rank: Number,
    isPassed: Boolean,
    needsManualReview: { type: Boolean, default: false },
    reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    reviewedAt: Date,
    // Duplicate-scan prevention: hash of QR + exam
    scanFingerprint: { type: String, index: true },
    submittedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  },
  { timestamps: true }
);

SubmissionSchema.index({ exam: 1, rollNumber: 1 });
SubmissionSchema.index({ exam: 1, scanFingerprint: 1 }, { unique: true, sparse: true });

module.exports = mongoose.model("Submission", SubmissionSchema);
