/**
 * Seed default users + a sample exam.
 * Run: npm run seed
 */
require("dotenv").config();
const mongoose = require("mongoose");
const connectDB = require("../config/db");
const User = require("../models/User");
const Exam = require("../models/Exam");

async function seed() {
  await connectDB();

  const users = [
    { name: "System Admin", email: "admin@omr.com", password: "admin123", role: "admin" },
    { name: "Evaluator User", email: "eval@omr.com", password: "eval123", role: "evaluator" },
    { name: "Demo Student", email: "student@omr.com", password: "student123", role: "student", rollNumber: "STU001" },
  ];

  let adminUser;
  for (const u of users) {
    const existing = await User.findOne({ email: u.email });
    if (existing) {
      console.log(`✓ ${u.email} already exists`);
      if (u.role === "admin") adminUser = existing;
      continue;
    }
    const created = await User.create(u);
    if (u.role === "admin") adminUser = created;
    console.log(`+ Created ${u.email} (${u.role})`);
  }

  // Sample exam with 100 questions, simple answer key
  const examExists = await Exam.findOne({ title: "Sample MCQ Test 100Q" });
  if (!examExists && adminUser) {
    const key = {};
    const opts = ["A", "B", "C", "D"];
    for (let i = 1; i <= 100; i++) key[i] = [opts[i % 4]];

    const subjectMap = {};
    for (let i = 1; i <= 25; i++) subjectMap[i] = "Mathematics";
    for (let i = 26; i <= 50; i++) subjectMap[i] = "Physics";
    for (let i = 51; i <= 75; i++) subjectMap[i] = "Chemistry";
    for (let i = 76; i <= 100; i++) subjectMap[i] = "Biology";

    await Exam.create({
      title: "Sample MCQ Test 100Q",
      description: "A demo 100-question MCQ exam for testing the OMR engine.",
      subject: "Mixed (Math/Phy/Chem/Bio)",
      totalQuestions: 100,
      marksPerQuestion: 1,
      negativeMarking: 0.25,
      allowMultipleAnswers: false,
      durationMinutes: 90,
      passPercentage: 33,
      answerKey: key,
      subjectMap,
      status: "active",
      examCode: "DEMO100",
      createdBy: adminUser._id,
    });
    console.log("+ Created sample exam 'Sample MCQ Test 100Q' (examCode: DEMO100)");
  }

  console.log("\n🌱 Seed complete.\n");
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
