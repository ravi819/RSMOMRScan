const AuditLog = require("../models/AuditLog");

async function logAudit(req, action, resource, resourceId, details = {}) {
  try {
    await AuditLog.create({
      user: req.user?._id,
      userEmail: req.user?.email,
      action,
      resource,
      resourceId: resourceId ? String(resourceId) : undefined,
      details,
      ip: req.ip,
      userAgent: req.headers["user-agent"],
    });
  } catch (err) {
    console.error("Audit log failed:", err.message);
  }
}

module.exports = { logAudit };
