import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../services/api";
import { Download, AlertTriangle } from "lucide-react";

const VerdictBadge = ({ v }) => {
  const map = {
    correct: "bg-emerald-100 text-emerald-700",
    partial: "bg-cyan-100 text-cyan-700",
    wrong: "bg-red-100 text-red-700",
    skipped: "bg-slate-100 text-slate-600",
    invalid_multi: "bg-amber-100 text-amber-700",
  };
  return <span className={`badge ${map[v] || "bg-slate-100"}`}>{v}</span>;
};

export default function ResultDetail() {
  const { id } = useParams();
  const [sub, setSub] = useState(null);

  useEffect(() => {
    api.get(`/results/${id}`).then((r) => setSub(r.data.submission));
  }, [id]);

  if (!sub) return <div className="p-6 text-slate-500">Loading…</div>;

  return (
    <div className="space-y-6">
      <div className="card bg-gradient-to-br from-brand-700 to-brand-900 text-white">
        <div className="flex items-start justify-between flex-wrap gap-3">
          <div>
            <div className="text-brand-200 text-sm">{sub.exam?.title}</div>
            <div className="text-3xl font-bold">{sub.student?.name || sub.rollNumber}</div>
            <div className="text-brand-200 text-xs">Roll: {sub.rollNumber || "—"}</div>
          </div>
          <a className="btn bg-white text-brand-800 hover:bg-brand-50"
            href={`/api/results/${sub._id}/scorecard.pdf`} target="_blank" rel="noreferrer">
            <Download className="w-4 h-4" /> Scorecard PDF
          </a>
        </div>
        <div className="grid sm:grid-cols-4 gap-3 mt-5">
          <Big label="Score" v={`${sub.score} / ${sub.maxScore}`} />
          <Big label="Percentage" v={`${sub.percentage}%`} />
          <Big label="Rank" v={sub.rank ? `#${sub.rank}` : "—"} />
          <Big label="Status" v={sub.isPassed ? "PASSED" : "FAILED"} />
        </div>
      </div>

      {sub.needsManualReview && (
        <div className="card flex items-center gap-3 border-amber-200 bg-amber-50">
          <AlertTriangle className="w-5 h-5 text-amber-600" />
          <div className="text-sm text-amber-800">
            Some answers have low confidence — manual review is recommended.
          </div>
        </div>
      )}

      {sub.previewImageB64 && (
        <div className="card">
          <h3 className="font-bold mb-2">Scanned Sheet Preview</h3>
          <img src={sub.previewImageB64} alt="preview"
            className="max-h-[500px] mx-auto rounded-lg border border-slate-200" />
        </div>
      )}

      <div className="card">
        <h3 className="font-bold text-lg mb-3">Question-wise Breakdown</h3>
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-2 max-h-[600px] overflow-auto">
          {sub.answers.map((a) => (
            <div key={a.question}
              className="rounded-lg p-2 text-xs bg-slate-50 border border-slate-100">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-700">Q{a.question}</span>
                <VerdictBadge v={a.verdict} />
              </div>
              <div className="mt-1 text-slate-600">
                Marked: <b>{a.selected?.join(",") || "—"}</b><br/>
                Correct: <b className="text-emerald-700">{a.correctAnswer?.join(",") || "—"}</b><br/>
                Marks: <b>{a.marks}</b>
                {a.needsReview && <span className="ml-1 text-amber-600">⚠</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const Big = ({ label, v }) => (
  <div>
    <div className="text-[11px] uppercase text-brand-200 tracking-wider">{label}</div>
    <div className="text-2xl font-bold">{v}</div>
  </div>
);
