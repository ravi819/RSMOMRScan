import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import toast from "react-hot-toast";

export default function Register() {
  const { register } = useAuth();
  const [f, setF] = useState({ name: "", email: "", password: "", role: "student", rollNumber: "" });
  const [loading, setLoading] = useState(false);
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await register(f);
      toast.success("Account created!");
    } catch (err) {
      toast.error(err.response?.data?.error || "Registration failed");
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-brand-50">
      <form onSubmit={submit} className="card w-full max-w-md space-y-4">
        <h1 className="text-2xl font-bold text-brand-900">Create Account</h1>
        <input className="input" placeholder="Full name" value={f.name}
          onChange={(e) => set("name", e.target.value)} required />
        <input className="input" placeholder="Email" type="email" value={f.email}
          onChange={(e) => set("email", e.target.value)} required />
        <input className="input" placeholder="Password (min 6 chars)" type="password" value={f.password}
          onChange={(e) => set("password", e.target.value)} required />
        <select className="input" value={f.role} onChange={(e) => set("role", e.target.value)}>
          <option value="student">Student</option>
          <option value="evaluator">Evaluator</option>
          <option value="admin">Admin</option>
        </select>
        {f.role === "student" && (
          <input className="input" placeholder="Roll number"
            value={f.rollNumber} onChange={(e) => set("rollNumber", e.target.value)} />
        )}
        <button className="btn-primary w-full" disabled={loading}>
          {loading ? "Creating…" : "Register"}
        </button>
        <div className="text-xs text-center text-slate-500">
          Already have an account? <Link to="/login" className="text-brand-700 font-medium">Sign in</Link>
        </div>
      </form>
    </div>
  );
}
