import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";
import { Award } from "lucide-react";

export default function MyResults() {
  const [subs, setSubs] = useState([]);
  useEffect(() => {
    api.get("/results/student/me").then((r) => setSubs(r.data.submissions));
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-2">
        <Award className="w-7 h-7 text-amber-500" /> My Results
      </h1>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {subs.map((s) => (
          <Link key={s._id} to={`/submissions/${s._id}`}
            className="card hover:shadow-lg transition">
            <div className="font-bold text-lg">{s.exam?.title}</div>
            <div className="text-xs text-slate-500 mb-3">
              {new Date(s.createdAt).toLocaleString()}
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-bold text-brand-700">{s.percentage}%</div>
                <div className="text-xs text-slate-500">{s.score}/{s.maxScore} marks</div>
              </div>
              <span className={`badge ${s.isPassed ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>
                {s.isPassed ? "Pass" : "Fail"}
              </span>
            </div>
          </Link>
        ))}
        {subs.length === 0 && (
          <div className="card text-center text-slate-500 col-span-full">
            No results yet.
          </div>
        )}
      </div>
    </div>
  );
}
