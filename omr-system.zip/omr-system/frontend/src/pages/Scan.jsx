import { useEffect, useRef, useState } from "react";
import api from "../services/api";
import toast from "react-hot-toast";
import { Camera, Upload, ScanLine, CheckCircle2, AlertTriangle, Loader2, RefreshCcw } from "lucide-react";
import { Link } from "react-router-dom";

export default function Scan() {
  const [exams, setExams] = useState([]);
  const [examId, setExamId] = useState("");
  const [mode, setMode] = useState("upload"); // upload | camera
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);

  useEffect(() => {
    api.get("/exams?status=active").then((r) => {
      setExams(r.data.exams);
      if (r.data.exams[0]) setExamId(r.data.exams[0]._id);
    });
    return () => stopCamera();
  }, []);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1920 }, height: { ideal: 1440 } },
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      toast.error("Camera access denied: " + err.message);
    }
  };

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
  };

  const capture = () => {
    if (!videoRef.current) return;
    const v = videoRef.current;
    const c = canvasRef.current;
    c.width = v.videoWidth;
    c.height = v.videoHeight;
    c.getContext("2d").drawImage(v, 0, 0);
    c.toBlob((blob) => {
      const f = new File([blob], `capture_${Date.now()}.jpg`, { type: "image/jpeg" });
      setFile(f);
      setPreviewUrl(URL.createObjectURL(blob));
      stopCamera();
      setMode("upload");
    }, "image/jpeg", 0.92);
  };

  const onFile = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
    setResult(null);
  };

  const submit = async () => {
    if (!file || !examId) return toast.error("Pick exam and file");
    setLoading(true); setResult(null);
    const fd = new FormData();
    fd.append("file", file);
    fd.append("examId", examId);
    try {
      const { data } = await api.post("/scan/upload", fd, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setResult(data.submission);
      toast.success("Sheet evaluated successfully!");
    } catch (err) {
      toast.error(err.response?.data?.error || "Scan failed");
    } finally { setLoading(false); }
  };

  const reset = () => { setFile(null); setPreviewUrl(null); setResult(null); };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-2">
          <ScanLine className="w-7 h-7 text-brand-700" /> Scan OMR Sheet
        </h1>
        <p className="text-slate-500">Upload, capture from camera, or batch-scan answer sheets</p>
      </div>

      <div className="card space-y-4">
        <div>
          <label className="text-sm font-medium text-slate-700">Select Exam</label>
          <select className="input mt-1" value={examId} onChange={(e) => setExamId(e.target.value)}>
            <option value="">— Choose an exam —</option>
            {exams.map((e) => (
              <option key={e._id} value={e._id}>
                {e.title} ({e.totalQuestions}Q • {e.examCode})
              </option>
            ))}
          </select>
        </div>

        <div className="flex gap-2 flex-wrap">
          <button
            className={mode === "upload" ? "btn-primary" : "btn-ghost"}
            onClick={() => { setMode("upload"); stopCamera(); }}>
            <Upload className="w-4 h-4" /> Upload File
          </button>
          <button
            className={mode === "camera" ? "btn-primary" : "btn-ghost"}
            onClick={() => { setMode("camera"); setTimeout(startCamera, 100); }}>
            <Camera className="w-4 h-4" /> Use Camera
          </button>
        </div>

        {mode === "upload" && (
          <div>
            <label htmlFor="file-up"
              className="block border-2 border-dashed border-brand-200 rounded-xl p-10 text-center cursor-pointer hover:bg-brand-50">
              <Upload className="w-8 h-8 text-brand-500 mx-auto mb-2" />
              <div className="font-medium text-slate-700">
                {file ? file.name : "Click to upload JPG / PNG / PDF"}
              </div>
              <div className="text-xs text-slate-500 mt-1">Max 20 MB</div>
            </label>
            <input id="file-up" type="file" accept="image/*,.pdf" className="hidden" onChange={onFile} />
          </div>
        )}

        {mode === "camera" && (
          <div className="relative bg-black rounded-xl overflow-hidden">
            <video ref={videoRef} autoPlay playsInline className="w-full max-h-[500px] object-contain" />
            <div className="absolute inset-0 pointer-events-none">
              <div className="scan-bar"></div>
              <div className="absolute inset-6 border-2 border-white/30 rounded-lg" />
            </div>
            <div className="p-3 bg-slate-900/90 flex justify-center">
              <button className="btn-primary" onClick={capture}>
                <Camera className="w-4 h-4" /> Capture
              </button>
            </div>
            <canvas ref={canvasRef} className="hidden" />
          </div>
        )}

        {previewUrl && (
          <div className="flex flex-col md:flex-row gap-4 items-start">
            <img src={previewUrl} alt="preview"
              className="w-full md:w-48 rounded-lg border border-slate-200" />
            <div className="flex-1 space-y-2">
              <div className="text-sm text-slate-600">Ready to scan</div>
              <div className="flex gap-2">
                <button onClick={submit} disabled={loading || !examId} className="btn-primary">
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ScanLine className="w-4 h-4" />}
                  {loading ? "Processing…" : "Scan & Evaluate"}
                </button>
                <button onClick={reset} className="btn-ghost">
                  <RefreshCcw className="w-4 h-4" /> Reset
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {result && (
        <div className="card border-2 border-brand-200">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-500" />
            <h2 className="text-xl font-bold">Evaluation Result</h2>
          </div>
          <div className="grid sm:grid-cols-4 gap-3 mb-4">
            <Tile label="Score" value={`${result.score} / ${result.maxScore}`} />
            <Tile label="Percentage" value={`${result.percentage}%`} accent />
            <Tile label="Correct / Wrong" value={`${result.correctCount} / ${result.wrongCount}`} />
            <Tile label="Status" value={result.isPassed ? "PASSED" : "FAILED"}
              color={result.isPassed ? "text-emerald-600" : "text-red-600"} />
          </div>
          {result.needsManualReview && (
            <div className="flex items-center gap-2 bg-amber-50 border border-amber-200 text-amber-800 p-3 rounded-lg text-sm">
              <AlertTriangle className="w-4 h-4" />
              Low confidence on some answers — manual review recommended.
            </div>
          )}
          <div className="mt-4 flex gap-2 flex-wrap">
            <Link to={`/submissions/${result._id}`} className="btn-primary">View Detailed Result</Link>
            <a href={`/api/results/${result._id}/scorecard.pdf`} target="_blank" rel="noreferrer"
              className="btn-ghost">Download Scorecard PDF</a>
            <button onClick={reset} className="btn-ghost">Scan Another</button>
          </div>
        </div>
      )}
    </div>
  );
}

function Tile({ label, value, accent, color }) {
  return (
    <div className={`rounded-xl p-4 ${accent ? "bg-brand-700 text-white" : "bg-slate-50"}`}>
      <div className={`text-[11px] uppercase tracking-wider ${accent ? "text-brand-100" : "text-slate-500"}`}>
        {label}
      </div>
      <div className={`text-2xl font-bold ${color || (accent ? "" : "text-slate-900")}`}>{value}</div>
    </div>
  );
}
