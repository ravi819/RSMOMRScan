import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import api from "../services/api";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from "recharts";
import { Trophy, Users, TrendingUp, Target } from "lucide-react";

const COLORS = ["#10b981", "#f59e0b", "#ef4444"];

export default function Analytics() {
  const { id } = useParams();
  const [data, setData] = useState(null);

  useEffect(() => {
    api.get(`/analytics/exam/${id}`).then((r) => setData(r.data));
  }, [id]);

  if (!data) return <div className="p-6 text-slate-500">Loading…</div>;
  if (data.totalSubmissions === 0)
    return <div className="card text-center text-slate-500">No submissions yet.</div>;

  const diffData = [
    { name: "Easy", value: data.difficulty.easy },
    { name: "Medium", value: data.difficulty.medium },
    { name: "Hard", value: data.difficulty.hard },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Analytics — {data.exam.title}</h1>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat icon={Users} label="Submissions" v={data.totalSubmissions} />
        <Stat icon={TrendingUp} label="Avg %" v={data.avgPercentage + "%"} />
        <Stat icon={Target} label="Pass Rate" v={data.passPercent + "%"} />
        <Stat icon={Trophy} label="Highest" v={data.highestScore} />
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="card">
          <h3 className="font-bold mb-3">Score Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={data.distribution}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="bucket" fontSize={11} />
              <YAxis fontSize={11} />
              <Tooltip />
              <Bar dataKey="count" fill="#1e40af" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3 className="font-bold mb-3">Question Difficulty</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={diffData} dataKey="value" nameKey="name" cx="50%" cy="50%"
                outerRadius={90} label>
                {diffData.map((_, i) => <Cell key={i} fill={COLORS[i]} />)}
              </Pie>
              <Legend />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <h3 className="font-bold mb-3">Top 10 Performers</h3>
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600">
            <tr>
              <th className="px-3 py-2 text-left">Rank</th>
              <th className="px-3 py-2 text-left">Name</th>
              <th className="px-3 py-2 text-left">Roll</th>
              <th className="px-3 py-2 text-right">Score</th>
              <th className="px-3 py-2 text-right">%</th>
            </tr>
          </thead>
          <tbody>
            {data.toppers.map((t) => (
              <tr key={t.rank} className="border-t border-slate-100">
                <td className="px-3 py-2 font-bold">{t.rank}</td>
                <td className="px-3 py-2">{t.name}</td>
                <td className="px-3 py-2 font-mono text-xs">{t.rollNumber}</td>
                <td className="px-3 py-2 text-right">{t.score}</td>
                <td className="px-3 py-2 text-right font-bold text-brand-700">{t.percentage}%</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h3 className="font-bold mb-3">Question-wise Accuracy</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data.questionAccuracy}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="question" fontSize={10} />
            <YAxis fontSize={10} unit="%" />
            <Tooltip />
            <Bar dataKey="accuracy" radius={[3, 3, 0, 0]}>
              {data.questionAccuracy.map((q, i) => (
                <Cell key={i}
                  fill={q.difficulty === "Easy" ? "#10b981" :
                        q.difficulty === "Medium" ? "#f59e0b" : "#ef4444"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

const Stat = ({ icon: Icon, label, v }) => (
  <div className="card flex items-center gap-3">
    <div className="w-10 h-10 rounded-xl bg-brand-50 flex items-center justify-center">
      <Icon className="w-5 h-5 text-brand-700" />
    </div>
    <div>
      <div className="text-xs text-slate-500">{label}</div>
      <div className="text-2xl font-bold">{v}</div>
    </div>
  </div>
);
