import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";
import { Plus, FileText, BarChart3, ListChecks, Trash2 } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import toast from "react-hot-toast";

export default function Exams() {
  const { user } = useAuth();
  const [exams, setExams] = useState([]);
  const load = () => api.get("/exams").then((r) => setExams(r.data.exams));
  useEffect(() => { load(); }, []);

  const remove = async (id) => {
    if (!confirm("Delete this exam?")) return;
    await api.delete(`/exams/${id}`);
    toast.success("Deleted");
    load();
  };

  const isAdmin = user?.role === "admin" || user?.role === "evaluator";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-3xl font-bold">Exams</h1>
        {isAdmin && (
          <Link to="/exams/new" className="btn-primary">
            <Plus className="w-4 h-4" /> New Exam
          </Link>
        )}
      </div>

      {exams.length === 0 && (
        <div className="card text-center text-slate-500">
          <FileText className="w-10 h-10 text-slate-300 mx-auto mb-2" />
          No exams found.
        </div>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {exams.map((e) => (
          <div key={e._id} className="card hover:shadow-lg transition">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="font-bold text-lg truncate">{e.title}</div>
                <div className="text-xs text-slate-500">{e.subject || "—"}</div>
              </div>
              <span className={`badge ${
                e.status === "active" ? "bg-emerald-100 text-emerald-700" :
                e.status === "draft" ? "bg-slate-200 text-slate-700" :
                "bg-slate-100 text-slate-600"
              }`}>{e.status}</span>
            </div>
            <div className="grid grid-cols-3 gap-2 my-3 text-xs">
              <Cell label="Questions" v={e.totalQuestions} />
              <Cell label="Marks" v={e.marksPerQuestion} />
              <Cell label="-Marking" v={e.negativeMarking} />
            </div>
            <div className="text-[11px] text-slate-500 mb-3">Code: <span className="font-mono">{e.examCode}</span></div>
            <div className="flex gap-2 flex-wrap">
              {isAdmin && (
                <>
                  <Link to={`/exams/${e._id}`} className="btn-ghost text-xs">Edit</Link>
                  <Link to={`/exams/${e._id}/results`} className="btn-ghost text-xs">
                    <ListChecks className="w-3.5 h-3.5" /> Results
                  </Link>
                  <Link to={`/exams/${e._id}/analytics`} className="btn-ghost text-xs">
                    <BarChart3 className="w-3.5 h-3.5" /> Analytics
                  </Link>
                  {user?.role === "admin" && (
                    <button onClick={() => remove(e._id)} className="btn-ghost text-xs !text-red-600 !border-red-200">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const Cell = ({ label, v }) => (
  <div className="bg-slate-50 rounded-lg p-2 text-center">
    <div className="text-[10px] uppercase text-slate-500">{label}</div>
    <div className="font-bold">{v}</div>
  </div>
);
