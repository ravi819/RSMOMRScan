import { useEffect, useState } from "react";
import api from "../services/api";
import { Shield } from "lucide-react";

export default function AuditLog() {
  const [logs, setLogs] = useState([]);
  useEffect(() => { api.get("/audit?limit=300").then((r) => setLogs(r.data.logs)); }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-2">
        <Shield className="w-7 h-7 text-brand-700" /> Audit Log
      </h1>
      <div className="card overflow-x-auto">
        <table className="w-full text-xs">
          <thead className="bg-slate-50 text-slate-600">
            <tr>
              <th className="px-3 py-2 text-left">When</th>
              <th className="px-3 py-2 text-left">User</th>
              <th className="px-3 py-2 text-left">Action</th>
              <th className="px-3 py-2 text-left">Resource</th>
              <th className="px-3 py-2 text-left">IP</th>
              <th className="px-3 py-2 text-left">Details</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((l) => (
              <tr key={l._id} className="border-t border-slate-100">
                <td className="px-3 py-2 text-slate-500 whitespace-nowrap">
                  {new Date(l.createdAt).toLocaleString()}
                </td>
                <td className="px-3 py-2">{l.userEmail || "—"}</td>
                <td className="px-3 py-2 font-mono">{l.action}</td>
                <td className="px-3 py-2">{l.resource} {l.resourceId ? `#${l.resourceId.slice(-6)}` : ""}</td>
                <td className="px-3 py-2 text-slate-500">{l.ip}</td>
                <td className="px-3 py-2 max-w-xs truncate text-slate-500">
                  {l.details ? JSON.stringify(l.details) : ""}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
