import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FileText, Users, TrendingUp, CheckCircle2, ScanLine, Award } from "lucide-react";
import api from "../services/api";
import { useAuth } from "../context/AuthContext.jsx";

export default function Dashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [myResults, setMyResults] = useState([]);

  useEffect(() => {
    if (user?.role === "student") {
      api.get("/results/student/me").then(r => setMyResults(r.data.submissions || []));
    } else {
      api.get("/analytics/overview").then(r => setStats(r.data));
    }
  }, [user]);

  if (user?.role === "student") {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Welcome, {user.name}</h1>
          <p className="text-slate-500">Your latest exam performance</p>
        </div>
        <div className="grid sm:grid-cols-3 gap-4">
          <StatCard label="Exams Taken" value={myResults.length} icon={FileText} />
          <StatCard label="Avg Percentage"
            value={myResults.length ?
              Math.round(myResults.reduce((s,x)=>s+x.percentage,0)/myResults.length) + "%" : "—"}
            icon={TrendingUp} />
          <StatCard label="Passed"
            value={myResults.filter(r=>r.isPassed).length}
            icon={CheckCircle2} />
        </div>
        <div className="card">
          <h2 className="font-semibold text-lg mb-4">Recent Results</h2>
          {myResults.length === 0 && <div className="text-slate-500 text-sm">No results yet.</div>}
          <div className="divide-y divide-slate-100">
            {myResults.slice(0,5).map((r) => (
              <Link key={r._id} to={`/submissions/${r._id}`}
                className="flex items-center justify-between py-3 hover:bg-slate-50 px-2 rounded-lg">
                <div>
                  <div className="font-medium">{r.exam?.title}</div>
                  <div className="text-xs text-slate-500">{new Date(r.createdAt).toLocaleString()}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-brand-700">{r.percentage}%</div>
                  <div className="text-xs text-slate-500">{r.score}/{r.maxScore}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Dashboard</h1>
          <p className="text-slate-500">Overview of all exams & submissions</p>
        </div>
        <Link to="/scan" className="btn-primary">
          <ScanLine className="w-4 h-4" /> Scan OMR Sheet
        </Link>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Exams" value={stats?.totalExams ?? "—"} icon={FileText} />
        <StatCard label="Submissions" value={stats?.totalSubmissions ?? "—"} icon={ScanLine} />
        <StatCard label="Pass Rate" value={(stats?.passRate ?? "—") + "%"} icon={Award} />
        <StatCard label="Recent" value={stats?.recent?.length ?? 0} icon={TrendingUp} />
      </div>
      <div className="card">
        <h2 className="font-semibold text-lg mb-4">Recent Submissions</h2>
        {!stats?.recent?.length && <div className="text-slate-500 text-sm">No submissions yet.</div>}
        <div className="divide-y divide-slate-100">
          {stats?.recent?.map((s) => (
            <Link key={s._id} to={`/submissions/${s._id}`}
              className="flex items-center justify-between py-3 hover:bg-slate-50 px-2 rounded-lg">
              <div className="min-w-0">
                <div className="font-medium truncate">{s.exam?.title || "—"}</div>
                <div className="text-xs text-slate-500">
                  {s.student?.name || s.rollNumber || "Anonymous"} • {new Date(s.createdAt).toLocaleString()}
                </div>
              </div>
              <div className="text-right shrink-0 ml-3">
                <div className="font-bold text-brand-700">{s.percentage}%</div>
                <div className="text-xs text-slate-500">{s.score}/{s.maxScore}</div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon: Icon }) {
  return (
    <div className="card flex items-center gap-4">
      <div className="w-12 h-12 rounded-xl bg-brand-50 flex items-center justify-center">
        <Icon className="w-5 h-5 text-brand-700" />
      </div>
      <div>
        <div className="text-2xl font-bold text-slate-900">{value}</div>
        <div className="text-xs text-slate-500">{label}</div>
      </div>
    </div>
  );
}
