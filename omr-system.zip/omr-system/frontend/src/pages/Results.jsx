import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../services/api";
import { Download, Eye, Trophy } from "lucide-react";

export default function Results() {
  const { id } = useParams();
  const [rows, setRows] = useState([]);

  useEffect(() => {
    api.get(`/results/exam/${id}`).then((r) => setRows(r.data.submissions));
  }, [id]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Trophy className="w-7 h-7 text-amber-500" /> Results
        </h1>
        <div className="flex gap-2">
          <a className="btn-ghost" href={`/api/results/exam/${id}/export.xlsx`} target="_blank" rel="noreferrer">
            <Download className="w-4 h-4" /> Excel
          </a>
          <a className="btn-ghost" href={`/api/results/exam/${id}/export.csv`} target="_blank" rel="noreferrer">
            <Download className="w-4 h-4" /> CSV
          </a>
        </div>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-slate-50 text-slate-600">
            <tr>
              <th className="px-3 py-2 text-left">Rank</th>
              <th className="px-3 py-2 text-left">Roll</th>
              <th className="px-3 py-2 text-left">Name</th>
              <th className="px-3 py-2 text-right">Score</th>
              <th className="px-3 py-2 text-right">%</th>
              <th className="px-3 py-2 text-right">✓/✗/○</th>
              <th className="px-3 py-2 text-center">Status</th>
              <th className="px-3 py-2 text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r._id} className="border-t border-slate-100 hover:bg-slate-50">
                <td className="px-3 py-2 font-bold">{r.rank || "—"}</td>
                <td className="px-3 py-2 font-mono">{r.rollNumber || "—"}</td>
                <td className="px-3 py-2">{r.student?.name || "Anonymous"}</td>
                <td className="px-3 py-2 text-right font-medium">{r.score}/{r.maxScore}</td>
                <td className="px-3 py-2 text-right font-bold text-brand-700">{r.percentage}%</td>
                <td className="px-3 py-2 text-right text-xs">
                  <span className="text-emerald-600">{r.correctCount}</span>/
                  <span className="text-red-600">{r.wrongCount}</span>/
                  <span className="text-slate-500">{r.skippedCount}</span>
                </td>
                <td className="px-3 py-2 text-center">
                  <span className={`badge ${r.isPassed ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>
                    {r.isPassed ? "Pass" : "Fail"}
                  </span>
                </td>
                <td className="px-3 py-2 text-center">
                  <Link to={`/submissions/${r._id}`} className="text-brand-700 hover:underline">
                    <Eye className="w-4 h-4 inline" />
                  </Link>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={8} className="text-center text-slate-500 py-6">No submissions yet</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
