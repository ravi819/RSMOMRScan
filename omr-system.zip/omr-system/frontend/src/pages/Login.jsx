import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import toast from "react-hot-toast";
import { GraduationCap, Loader2 } from "lucide-react";

export default function Login() {
  const { login } = useAuth();
  const [email, setEmail] = useState("admin@omr.com");
  const [password, setPassword] = useState("admin123");
  const [loading, setLoading] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      toast.success("Welcome!");
    } catch (err) {
      toast.error(err.response?.data?.error || "Login failed");
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-brand-50 via-white to-brand-100">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex w-14 h-14 rounded-2xl bg-brand-700 items-center justify-center mb-3">
            <GraduationCap className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-brand-900">AI OMR Scanner</h1>
          <p className="text-slate-500 mt-1">Sign in to your account</p>
        </div>
        <form onSubmit={submit} className="card space-y-4">
          <div>
            <label className="text-sm font-medium text-slate-700">Email</label>
            <input className="input mt-1" value={email}
              onChange={(e) => setEmail(e.target.value)} type="email" required />
          </div>
          <div>
            <label className="text-sm font-medium text-slate-700">Password</label>
            <input className="input mt-1" value={password}
              onChange={(e) => setPassword(e.target.value)} type="password" required />
          </div>
          <button className="btn-primary w-full" disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Sign In"}
          </button>
          <div className="text-xs text-center text-slate-500">
            Don't have an account? <Link to="/register" className="text-brand-700 font-medium">Register</Link>
          </div>
          <div className="text-xs bg-brand-50 border border-brand-100 rounded-lg p-3 text-slate-600">
            <strong>Demo:</strong> admin@omr.com / admin123 • eval@omr.com / eval123 • student@omr.com / student123
          </div>
        </form>
      </div>
    </div>
  );
}
