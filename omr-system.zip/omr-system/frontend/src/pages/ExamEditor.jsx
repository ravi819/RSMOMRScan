import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../services/api";
import toast from "react-hot-toast";
import { Save, QrCode, FileText, Upload } from "lucide-react";

const OPTIONS = ["A", "B", "C", "D"];

export default function ExamEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState({
    title: "", description: "", subject: "",
    totalQuestions: 100, marksPerQuestion: 1, negativeMarking: 0,
    allowMultipleAnswers: false, durationMinutes: 60, passPercentage: 33,
    status: "draft", answerKey: {},
  });
  const [qr, setQr] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (id && id !== "new") {
      api.get(`/exams/${id}`).then((r) => {
        const ex = r.data.exam;
        // Map -> object
        const ak = {};
        Object.entries(ex.answerKey || {}).forEach(([k, v]) => { ak[k] = Array.isArray(v) ? v : [v]; });
        ex.answerKey = ak;
        setExam(ex);
      });
    }
  }, [id]);

  const set = (k, v) => setExam((s) => ({ ...s, [k]: v }));

  const save = async () => {
    setSaving(true);
    try {
      let resp;
      const payload = { ...exam };
      if (id && id !== "new") {
        resp = await api.patch(`/exams/${id}`, payload);
      } else {
        resp = await api.post("/exams", payload);
      }
      // Save answer key separately to use Map endpoint
      await api.post(`/exams/${resp.data.exam._id}/answer-key`, {
        answerKey: exam.answerKey,
      });
      toast.success("Saved!");
      navigate(`/exams/${resp.data.exam._id}`);
      setExam(resp.data.exam);
    } catch (err) {
      toast.error(err.response?.data?.error || "Save failed");
    } finally { setSaving(false); }
  };

  const setAnswer = (q, opt) => {
    setExam((s) => {
      const cur = s.answerKey[q] || [];
      const next = s.allowMultipleAnswers
        ? cur.includes(opt) ? cur.filter(x => x !== opt) : [...cur, opt]
        : [opt];
      return { ...s, answerKey: { ...s.answerKey, [q]: next } };
    });
  };

  const autoFillRandom = () => {
    const ak = {};
    for (let i = 1; i <= exam.totalQuestions; i++) ak[i] = [OPTIONS[Math.floor(Math.random() * 4)]];
    set("answerKey", ak);
    toast.success("Auto-filled (random)");
  };

  const showQR = async () => {
    if (!exam._id) return toast.error("Save exam first");
    const { data } = await api.get(`/exams/${exam._id}/qrcode`);
    setQr(data);
  };

  const importKeyJSON = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    try {
      const obj = JSON.parse(text);
      const norm = {};
      for (const [k, v] of Object.entries(obj)) norm[k] = Array.isArray(v) ? v : [v];
      set("answerKey", norm);
      toast.success(`Imported ${Object.keys(norm).length} answers`);
    } catch { toast.error("Invalid JSON"); }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <FileText className="w-7 h-7 text-brand-700" />
          {id && id !== "new" ? "Edit Exam" : "New Exam"}
        </h1>
        <div className="flex gap-2">
          {exam._id && (
            <button onClick={showQR} className="btn-ghost">
              <QrCode className="w-4 h-4" /> QR Code
            </button>
          )}
          <button onClick={save} disabled={saving} className="btn-primary">
            <Save className="w-4 h-4" /> {saving ? "Saving…" : "Save Exam"}
          </button>
        </div>
      </div>

      <div className="card grid sm:grid-cols-2 gap-4">
        <div className="sm:col-span-2">
          <label className="text-sm font-medium">Title *</label>
          <input className="input mt-1" value={exam.title} onChange={(e) => set("title", e.target.value)} />
        </div>
        <div className="sm:col-span-2">
          <label className="text-sm font-medium">Description</label>
          <textarea className="input mt-1" rows={2} value={exam.description || ""}
            onChange={(e) => set("description", e.target.value)} />
        </div>
        <div>
          <label className="text-sm font-medium">Subject</label>
          <input className="input mt-1" value={exam.subject || ""}
            onChange={(e) => set("subject", e.target.value)} />
        </div>
        <div>
          <label className="text-sm font-medium">Status</label>
          <select className="input mt-1" value={exam.status} onChange={(e) => set("status", e.target.value)}>
            <option value="draft">Draft</option>
            <option value="active">Active</option>
            <option value="completed">Completed</option>
            <option value="archived">Archived</option>
          </select>
        </div>
        <NumInput label="Total Questions" v={exam.totalQuestions}
          on={(v) => set("totalQuestions", v)} min={10} max={300} />
        <NumInput label="Marks / Question" v={exam.marksPerQuestion}
          on={(v) => set("marksPerQuestion", v)} step={0.5} />
        <NumInput label="Negative Marking" v={exam.negativeMarking}
          on={(v) => set("negativeMarking", v)} step={0.25} />
        <NumInput label="Duration (min)" v={exam.durationMinutes}
          on={(v) => set("durationMinutes", v)} />
        <NumInput label="Pass %" v={exam.passPercentage} on={(v) => set("passPercentage", v)} />
        <label className="flex items-center gap-2 mt-6 sm:col-span-2">
          <input type="checkbox" checked={exam.allowMultipleAnswers}
            onChange={(e) => set("allowMultipleAnswers", e.target.checked)} />
          <span className="text-sm">Allow multiple correct answers per question</span>
        </label>
      </div>

      <div className="card">
        <div className="flex items-center justify-between flex-wrap gap-2 mb-3">
          <h2 className="font-bold text-lg">Answer Key ({Object.keys(exam.answerKey).length} / {exam.totalQuestions})</h2>
          <div className="flex gap-2">
            <label className="btn-ghost cursor-pointer text-xs">
              <Upload className="w-3.5 h-3.5" /> Import JSON
              <input type="file" accept=".json" className="hidden" onChange={importKeyJSON} />
            </label>
            <button onClick={autoFillRandom} className="btn-ghost text-xs">Auto-fill (random)</button>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 max-h-[500px] overflow-auto pr-1">
          {Array.from({ length: exam.totalQuestions }, (_, i) => i + 1).map((q) => (
            <div key={q} className="flex items-center gap-1 bg-slate-50 rounded px-2 py-1">
              <span className="text-xs font-medium text-slate-600 w-8">Q{q}</span>
              {OPTIONS.map((o) => {
                const selected = (exam.answerKey[q] || []).includes(o);
                return (
                  <button key={o} onClick={() => setAnswer(q, o)}
                    className={`w-7 h-7 text-xs rounded-full font-bold transition
                      ${selected ? "bg-brand-700 text-white" : "bg-white text-slate-500 border border-slate-200"}`}>
                    {o}
                  </button>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {qr && (
        <div className="card text-center">
          <h3 className="font-bold mb-2">Exam QR Code</h3>
          <img src={qr.qr} alt="QR" className="w-56 h-56 mx-auto" />
          <div className="text-xs text-slate-500 mt-2 font-mono break-all">{qr.payload}</div>
          <p className="text-xs text-slate-500 mt-2">Print this on each OMR sheet for auto-validation.</p>
        </div>
      )}
    </div>
  );
}

const NumInput = ({ label, v, on, step = 1, min, max }) => (
  <div>
    <label className="text-sm font-medium">{label}</label>
    <input type="number" step={step} min={min} max={max} className="input mt-1"
      value={v} onChange={(e) => on(parseFloat(e.target.value))} />
  </div>
);
