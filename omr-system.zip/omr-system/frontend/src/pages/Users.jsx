import { useEffect, useState } from "react";
import api from "../services/api";
import toast from "react-hot-toast";
import { Users as UsersIcon } from "lucide-react";

export default function Users() {
  const [users, setUsers] = useState([]);
  const [q, setQ] = useState("");
  const load = () => api.get("/users" + (q ? `?q=${encodeURIComponent(q)}` : ""))
    .then((r) => setUsers(r.data.users));
  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const updateRole = async (id, role) => {
    await api.patch(`/users/${id}`, { role });
    toast.success("Role updated"); load();
  };
  const toggleActive = async (u) => {
    await api.patch(`/users/${u._id}`, { isActive: !u.isActive });
    load();
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-2">
        <UsersIcon className="w-7 h-7 text-brand-700" /> Users
      </h1>
      <div className="card">
        <div className="flex gap-2 mb-3">
          <input className="input" placeholder="Search name/email/roll..."
            value={q} onChange={(e) => setQ(e.target.value)} />
          <button className="btn-primary" onClick={load}>Search</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 text-slate-600">
              <tr>
                <th className="px-3 py-2 text-left">Name</th>
                <th className="px-3 py-2 text-left">Email</th>
                <th className="px-3 py-2 text-left">Roll</th>
                <th className="px-3 py-2 text-left">Role</th>
                <th className="px-3 py-2 text-center">Active</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u._id} className="border-t border-slate-100">
                  <td className="px-3 py-2">{u.name}</td>
                  <td className="px-3 py-2 text-slate-600">{u.email}</td>
                  <td className="px-3 py-2 font-mono text-xs">{u.rollNumber || "—"}</td>
                  <td className="px-3 py-2">
                    <select className="input !py-1 !px-2 text-xs" value={u.role}
                      onChange={(e) => updateRole(u._id, e.target.value)}>
                      <option value="student">Student</option>
                      <option value="evaluator">Evaluator</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                  <td className="px-3 py-2 text-center">
                    <button onClick={() => toggleActive(u)}
                      className={`badge ${u.isActive ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>
                      {u.isActive ? "Active" : "Disabled"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
