import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import {
  LayoutDashboard, ScanLine, FileText, BarChart3, Users, Shield, Award,
  LogOut, GraduationCap, Menu, X,
} from "lucide-react";
import { useState } from "react";

export default function Layout() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const links = [
    { to: "/", label: "Dashboard", icon: LayoutDashboard, roles: ["admin","evaluator","student"] },
    { to: "/scan", label: "Scan Sheet", icon: ScanLine, roles: ["admin","evaluator"] },
    { to: "/exams", label: "Exams", icon: FileText, roles: ["admin","evaluator","student"] },
    { to: "/my-results", label: "My Results", icon: Award, roles: ["student"] },
    { to: "/users", label: "Users", icon: Users, roles: ["admin"] },
    { to: "/audit", label: "Audit Log", icon: Shield, roles: ["admin"] },
  ].filter(l => l.roles.includes(user?.role));

  return (
    <div className="min-h-screen flex bg-slate-50">
      {/* Sidebar */}
      <aside className={`${open ? "translate-x-0" : "-translate-x-full"}
        md:translate-x-0 fixed md:static z-30 w-64 h-screen bg-white border-r border-slate-200
        transition-transform flex flex-col`}>
        <div className="flex items-center gap-2 px-5 py-5 border-b border-slate-100">
          <div className="w-9 h-9 rounded-xl bg-brand-700 flex items-center justify-center">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-bold text-brand-800">AI OMR</div>
            <div className="text-[11px] text-slate-500 -mt-0.5">Scanner & Evaluation</div>
          </div>
          <button className="ml-auto md:hidden" onClick={() => setOpen(false)}>
            <X className="w-5 h-5" />
          </button>
        </div>
        <nav className="flex-1 p-3 space-y-1">
          {links.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition
                ${isActive
                  ? "bg-brand-50 text-brand-800"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"}`
              }
            >
              <Icon className="w-4 h-4" />
              {label}
            </NavLink>
          ))}
        </nav>
        <div className="p-3 border-t border-slate-100">
          <div className="px-3 py-2 mb-1">
            <div className="text-sm font-medium text-slate-800 truncate">{user?.name}</div>
            <div className="text-[11px] text-slate-500 capitalize">{user?.role}</div>
          </div>
          <button onClick={logout}
            className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg">
            <LogOut className="w-4 h-4" /> Log out
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden flex items-center gap-3 bg-white border-b border-slate-200 px-4 py-3">
          <button onClick={() => setOpen(true)}><Menu className="w-5 h-5" /></button>
          <div className="font-semibold text-brand-800">AI OMR</div>
        </header>
        <main className="flex-1 p-4 md:p-8 overflow-x-hidden">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
