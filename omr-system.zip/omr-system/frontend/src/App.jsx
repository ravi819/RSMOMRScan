import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext.jsx";
import Layout from "./components/Layout.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Exams from "./pages/Exams.jsx";
import ExamEditor from "./pages/ExamEditor.jsx";
import Scan from "./pages/Scan.jsx";
import Results from "./pages/Results.jsx";
import ResultDetail from "./pages/ResultDetail.jsx";
import Analytics from "./pages/Analytics.jsx";
import Users from "./pages/Users.jsx";
import MyResults from "./pages/MyResults.jsx";
import AuditLog from "./pages/AuditLog.jsx";

function ProtectedRoute({ children, roles }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="p-10 text-center text-slate-500">Loading…</div>;
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { user } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
      <Route path="/register" element={user ? <Navigate to="/" /> : <Register />} />
      <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/scan" element={<Scan />} />
        <Route path="/exams" element={<Exams />} />
        <Route path="/exams/new" element={<ProtectedRoute roles={["admin","evaluator"]}><ExamEditor /></ProtectedRoute>} />
        <Route path="/exams/:id" element={<ProtectedRoute roles={["admin","evaluator"]}><ExamEditor /></ProtectedRoute>} />
        <Route path="/exams/:id/results" element={<ProtectedRoute roles={["admin","evaluator"]}><Results /></ProtectedRoute>} />
        <Route path="/submissions/:id" element={<ResultDetail />} />
        <Route path="/exams/:id/analytics" element={<ProtectedRoute roles={["admin","evaluator"]}><Analytics /></ProtectedRoute>} />
        <Route path="/users" element={<ProtectedRoute roles={["admin"]}><Users /></ProtectedRoute>} />
        <Route path="/audit" element={<ProtectedRoute roles={["admin"]}><AuditLog /></ProtectedRoute>} />
        <Route path="/my-results" element={<MyResults />} />
      </Route>
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}
