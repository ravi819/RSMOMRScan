"""
Flask microservice exposing the OMR engine over HTTP.
Endpoints:
  GET  /health           -> status check
  POST /scan             -> multipart file upload (jpg/png/pdf) -> answers
  POST /evaluate         -> JSON {answers, answer_key, ...} -> score
  POST /scan-and-eval    -> file + answer_key -> full result
"""
import os
import io
import json
import tempfile
from flask import Flask, request, jsonify
from flask_cors import CORS

from omr_processor import process_image, evaluate, DEFAULT_TEMPLATE

try:
    from pdf2image import convert_from_bytes
except Exception:
    convert_from_bytes = None

app = Flask(__name__)
CORS(app)

ALLOWED_EXT = {"jpg", "jpeg", "png", "bmp", "pdf"}


def _read_upload_to_image_bytes(file_storage):
    """Returns a list of image-bytes (PDF yields one per page)."""
    filename = (file_storage.filename or "").lower()
    raw = file_storage.read()
    if filename.endswith(".pdf"):
        if convert_from_bytes is None:
            raise RuntimeError("pdf2image not available — install poppler-utils")
        pages = convert_from_bytes(raw, dpi=200)
        out = []
        for p in pages:
            buf = io.BytesIO()
            p.save(buf, format="JPEG")
            out.append(buf.getvalue())
        return out
    return [raw]


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "omr-engine", "version": "1.0.0"})


@app.route("/scan", methods=["POST"])
def scan():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded (field name must be 'file')"}), 400
    f = request.files["file"]
    ext = (f.filename or "").rsplit(".", 1)[-1].lower()
    if ext not in ALLOWED_EXT:
        return jsonify({"error": f"Unsupported file type: {ext}"}), 400

    # Optional custom template
    template = None
    if "template" in request.form:
        try:
            template = json.loads(request.form["template"])
        except Exception:
            return jsonify({"error": "Invalid template JSON"}), 400

    try:
        image_bytes_list = _read_upload_to_image_bytes(f)
    except Exception as e:
        return jsonify({"error": f"Failed to read file: {e}"}), 400

    # Process first page only (extend later for multi-page batches)
    result = process_image(image_bytes_list[0], template)
    return jsonify(result)


@app.route("/evaluate", methods=["POST"])
def evaluate_route():
    data = request.get_json(silent=True) or {}
    answers = data.get("answers")
    answer_key = data.get("answer_key")
    if not answers or not answer_key:
        return jsonify({"error": "answers and answer_key are required"}), 400

    result = evaluate(
        answers,
        answer_key,
        marks_per_q=float(data.get("marks_per_q", 1)),
        negative_marking=float(data.get("negative_marking", 0)),
        allow_multiple=bool(data.get("allow_multiple", False)),
    )
    return jsonify(result)


@app.route("/scan-and-eval", methods=["POST"])
def scan_and_eval():
    """Combined: scan file + immediately evaluate against an answer key."""
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    f = request.files["file"]

    answer_key_raw = request.form.get("answer_key")
    if not answer_key_raw:
        return jsonify({"error": "answer_key form field required (JSON)"}), 400
    try:
        answer_key = json.loads(answer_key_raw)
    except Exception:
        return jsonify({"error": "Invalid answer_key JSON"}), 400

    marks_per_q = float(request.form.get("marks_per_q", 1))
    negative_marking = float(request.form.get("negative_marking", 0))
    allow_multiple = request.form.get("allow_multiple", "false").lower() == "true"

    try:
        image_bytes_list = _read_upload_to_image_bytes(f)
    except Exception as e:
        return jsonify({"error": f"Failed to read file: {e}"}), 400

    scan_result = process_image(image_bytes_list[0])
    if not scan_result.get("success"):
        return jsonify(scan_result), 500

    eval_result = evaluate(
        scan_result["answers"], answer_key,
        marks_per_q=marks_per_q,
        negative_marking=negative_marking,
        allow_multiple=allow_multiple,
    )
    return jsonify({
        "scan": {
            "qr_data": scan_result["qr_data"],
            "roll_number": scan_result["roll_number"],
            "stats": scan_result["stats"],
            "preview_image": scan_result["preview_image"],
        },
        "evaluation": eval_result,
    })


@app.route("/template", methods=["GET"])
def get_template():
    return jsonify(DEFAULT_TEMPLATE)


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    app.run(host="0.0.0.0", port=port, debug=False)
