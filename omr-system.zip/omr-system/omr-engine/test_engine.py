"""Quick CLI test: python test_engine.py path/to/sheet.jpg"""
import sys
import json
from omr_processor import process_image, evaluate

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python test_engine.py <image_path> [answer_key.json]")
        sys.exit(1)

    with open(sys.argv[1], "rb") as f:
        img_bytes = f.read()

    result = process_image(img_bytes)
    # Strip preview image for terminal readability
    result_print = {k: v for k, v in result.items() if k != "preview_image"}
    print(json.dumps(result_print, indent=2))

    if len(sys.argv) > 2 and result.get("success"):
        with open(sys.argv[2]) as f:
            key = json.load(f)
        ev = evaluate(result["answers"], key, marks_per_q=1, negative_marking=0.25)
        print("\n--- EVALUATION ---")
        print(json.dumps({k: v for k, v in ev.items() if k != "details"}, indent=2))
