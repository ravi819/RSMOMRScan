"""
OMR Processor — Core image processing engine.

Pipeline:
  1. Load image (or convert PDF page -> image)
  2. Preprocess: grayscale, blur, adaptive threshold
  3. Find sheet contour (largest 4-point contour) -> perspective warp
  4. Locate bubble grid (assumes 100Q standard template: 4 cols x 25 rows x 4 options)
  5. Detect filled bubbles by pixel-density per bubble ROI
  6. Compute confidence (fill ratio vs. neighbors)
  7. Decode QR/barcode if present
  8. OCR roll number region
  9. Return structured answers + metadata
"""
import cv2
import numpy as np
from PIL import Image
import io
import base64

try:
    from pyzbar.pyzbar import decode as zbar_decode
except Exception:
    zbar_decode = None

try:
    import pytesseract
except Exception:
    pytesseract = None


# ---------- Configuration ----------
DEFAULT_TEMPLATE = {
    "num_questions": 100,
    "options_per_q": 4,           # A B C D
    "columns": 4,                  # 4 vertical columns of 25 questions
    "rows_per_col": 25,
    # Normalized coordinates (0..1) of the bubble grid relative to the warped sheet
    # The grid occupies the middle-lower portion. Tune per actual template.
    "grid_top": 0.30,
    "grid_bottom": 0.95,
    "grid_left": 0.05,
    "grid_right": 0.95,
    # Roll number region (top-left area)
    "roll_top": 0.08,
    "roll_bottom": 0.22,
    "roll_left": 0.05,
    "roll_right": 0.45,
    # QR region (top-right)
    "qr_top": 0.02,
    "qr_bottom": 0.18,
    "qr_left": 0.70,
    "qr_right": 0.98,
    "fill_threshold": 0.35,        # bubble considered filled if dark-ratio > this
    "warp_width": 800,
    "warp_height": 1100,
}

OPTION_LABELS = ["A", "B", "C", "D", "E"]


# ---------- Helpers ----------
def order_points(pts):
    """Order 4 points: top-left, top-right, bottom-right, bottom-left."""
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect


def four_point_transform(image, pts, target_w, target_h):
    """Warp image to a top-down rectangular view."""
    rect = order_points(pts)
    dst = np.array(
        [[0, 0], [target_w - 1, 0], [target_w - 1, target_h - 1], [0, target_h - 1]],
        dtype="float32",
    )
    M = cv2.getPerspectiveTransform(rect, dst)
    return cv2.warpPerspective(image, M, (target_w, target_h))


def enhance_image(img):
    """Denoise + auto-contrast for low-light tolerance."""
    if len(img.shape) == 3:
        lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
        l = clahe.apply(l)
        img = cv2.merge((l, a, b))
        img = cv2.cvtColor(img, cv2.COLOR_LAB2BGR)
    img = cv2.fastNlMeansDenoisingColored(img, None, 7, 7, 7, 21) if len(img.shape) == 3 else img
    return img


def find_sheet_contour(image):
    """Return the 4-point contour of the answer sheet."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged = cv2.Canny(blurred, 50, 200)
    edged = cv2.dilate(edged, np.ones((3, 3), np.uint8), iterations=2)

    contours, _ = cv2.findContours(edged, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)

    for c in contours[:5]:
        peri = cv2.arcLength(c, True)
        approx = cv2.approxPolyDP(c, 0.02 * peri, True)
        if len(approx) == 4 and cv2.contourArea(c) > 0.2 * image.shape[0] * image.shape[1]:
            return approx.reshape(4, 2)
    # Fallback: use full image corners
    h, w = image.shape[:2]
    return np.array([[0, 0], [w, 0], [w, h], [0, h]], dtype="float32")


def decode_qr(image, region):
    """Decode QR/barcode from a normalized region. Returns string or None."""
    if zbar_decode is None:
        return None
    h, w = image.shape[:2]
    y1, y2 = int(region["qr_top"] * h), int(region["qr_bottom"] * h)
    x1, x2 = int(region["qr_left"] * w), int(region["qr_right"] * w)
    roi = image[y1:y2, x1:x2]
    if roi.size == 0:
        return None
    try:
        decoded = zbar_decode(roi)
        if decoded:
            return decoded[0].data.decode("utf-8", errors="ignore")
    except Exception:
        pass
    return None


def ocr_roll_number(image, region):
    """OCR the roll number region; returns digits-only string."""
    if pytesseract is None:
        return None
    h, w = image.shape[:2]
    y1, y2 = int(region["roll_top"] * h), int(region["roll_bottom"] * h)
    x1, x2 = int(region["roll_left"] * w), int(region["roll_right"] * w)
    roi = image[y1:y2, x1:x2]
    if roi.size == 0:
        return None
    gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY) if len(roi.shape) == 3 else roi
    gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    try:
        text = pytesseract.image_to_string(
            gray, config="--psm 7 -c tessedit_char_whitelist=0123456789"
        )
        digits = "".join(ch for ch in text if ch.isdigit())
        return digits or None
    except Exception:
        return None


def detect_bubbles(warped, template=DEFAULT_TEMPLATE):
    """
    Iterate over the grid cells, compute fill ratio, return per-question answers.
    Returns: list of dicts {question, selected: [option_label], confidence, fill_ratios}
    """
    h, w = warped.shape[:2]
    gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY) if len(warped.shape) == 3 else warped
    # Otsu threshold inverted -> filled bubbles become white (255)
    thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

    grid_top = int(template["grid_top"] * h)
    grid_bottom = int(template["grid_bottom"] * h)
    grid_left = int(template["grid_left"] * w)
    grid_right = int(template["grid_right"] * w)

    grid_w = grid_right - grid_left
    grid_h = grid_bottom - grid_top

    cols = template["columns"]
    rows = template["rows_per_col"]
    opts = template["options_per_q"]

    col_width = grid_w / cols
    row_height = grid_h / rows

    # Inside each column cell: a question number label + N option bubbles
    # Bubbles occupy roughly the right 70% of the column
    bubble_area_left_frac = 0.30
    bubble_area_right_frac = 0.95
    fill_thr = template["fill_threshold"]

    results = []
    qnum = 0
    for col in range(cols):
        for row in range(rows):
            qnum += 1
            if qnum > template["num_questions"]:
                break
            cell_x0 = grid_left + col * col_width
            cell_y0 = grid_top + row * row_height
            cell_x1 = cell_x0 + col_width
            cell_y1 = cell_y0 + row_height

            bub_x0 = cell_x0 + col_width * bubble_area_left_frac
            bub_x1 = cell_x0 + col_width * bubble_area_right_frac
            bub_w = (bub_x1 - bub_x0) / opts

            fill_ratios = []
            for o in range(opts):
                x0 = int(bub_x0 + o * bub_w)
                x1 = int(bub_x0 + (o + 1) * bub_w)
                y0 = int(cell_y0 + row_height * 0.15)
                y1 = int(cell_y1 - row_height * 0.15)
                roi = thresh[y0:y1, x0:x1]
                if roi.size == 0:
                    fill_ratios.append(0.0)
                    continue
                ratio = float(np.sum(roi > 127)) / roi.size
                fill_ratios.append(round(ratio, 3))

            max_ratio = max(fill_ratios) if fill_ratios else 0.0
            selected = []
            for i, r in enumerate(fill_ratios):
                if r >= fill_thr and r >= max_ratio * 0.85:
                    selected.append(OPTION_LABELS[i])

            # Confidence: gap between top fill and second-highest
            sorted_r = sorted(fill_ratios, reverse=True)
            if len(sorted_r) > 1:
                gap = sorted_r[0] - sorted_r[1]
                confidence = round(min(1.0, gap * 2 + (sorted_r[0] if selected else 0)), 3)
            else:
                confidence = round(sorted_r[0], 3) if sorted_r else 0.0

            results.append({
                "question": qnum,
                "selected": selected,
                "confidence": confidence,
                "fill_ratios": fill_ratios,
                "needs_review": confidence < 0.35 or len(selected) > 1,
            })
        if qnum > template["num_questions"]:
            break
    return results


def process_image(img_bytes, template=None):
    """Main entry: bytes -> structured OMR result."""
    if template is None:
        template = DEFAULT_TEMPLATE.copy()

    # Decode bytes to OpenCV image
    arr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return {"error": "Could not decode image"}

    # 1. Enhance
    enhanced = enhance_image(img)

    # 2. Find sheet & warp
    contour = find_sheet_contour(enhanced)
    warped = four_point_transform(
        enhanced, contour.astype("float32"),
        template["warp_width"], template["warp_height"]
    )

    # 3. QR + OCR
    qr_data = decode_qr(warped, template)
    roll_number = ocr_roll_number(warped, template)

    # 4. Bubble detection
    answers = detect_bubbles(warped, template)

    # 5. Stats
    total = template["num_questions"]
    answered = sum(1 for a in answers if a["selected"])
    review = sum(1 for a in answers if a["needs_review"])
    avg_conf = (sum(a["confidence"] for a in answers) / total) if total else 0

    # 6. Encode preview (warped, resized) as base64 for UI display
    preview = cv2.resize(warped, (400, 550))
    _, buf = cv2.imencode(".jpg", preview, [cv2.IMWRITE_JPEG_QUALITY, 70])
    preview_b64 = base64.b64encode(buf).decode("utf-8")

    return {
        "success": True,
        "qr_data": qr_data,
        "roll_number": roll_number,
        "answers": answers,
        "stats": {
            "total_questions": total,
            "answered": answered,
            "skipped": total - answered,
            "needs_review": review,
            "avg_confidence": round(avg_conf, 3),
        },
        "preview_image": f"data:image/jpeg;base64,{preview_b64}",
    }


def evaluate(answers, answer_key, marks_per_q=1, negative_marking=0.0,
             allow_multiple=False):
    """
    Compare detected answers to the key, compute score.
    answer_key: {question_num: [correct_option_labels]}
    Returns: per-question evaluation + totals.
    """
    details = []
    score = 0.0
    correct = 0
    wrong = 0
    skipped = 0

    for a in answers:
        q = a["question"]
        key = answer_key.get(str(q)) or answer_key.get(q) or []
        if isinstance(key, str):
            key = [key]
        selected = a["selected"]

        if not selected:
            verdict = "skipped"
            marks = 0
            skipped += 1
        elif allow_multiple:
            if set(selected) == set(key):
                verdict = "correct"
                marks = marks_per_q
                correct += 1
            elif set(selected).issubset(set(key)):
                # partial credit
                verdict = "partial"
                marks = round(marks_per_q * len(selected) / len(key), 2)
                correct += 1
            else:
                verdict = "wrong"
                marks = -negative_marking
                wrong += 1
        else:
            if len(selected) == 1 and selected[0] in key:
                verdict = "correct"
                marks = marks_per_q
                correct += 1
            elif len(selected) > 1:
                verdict = "invalid_multi"
                marks = -negative_marking
                wrong += 1
            else:
                verdict = "wrong"
                marks = -negative_marking
                wrong += 1

        score += marks
        details.append({
            "question": q,
            "selected": selected,
            "correct_answer": key,
            "verdict": verdict,
            "marks": marks,
            "confidence": a.get("confidence", 0),
            "needs_review": a.get("needs_review", False),
        })

    total = len(answers)
    max_score = total * marks_per_q
    return {
        "score": round(score, 2),
        "max_score": max_score,
        "percentage": round((score / max_score) * 100, 2) if max_score else 0,
        "correct": correct,
        "wrong": wrong,
        "skipped": skipped,
        "details": details,
    }
